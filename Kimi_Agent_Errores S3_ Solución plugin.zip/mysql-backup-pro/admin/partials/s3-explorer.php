<?php
if (!defined('ABSPATH')) exit;

$s3_configured = MBP\S3Native::configured();
$cfg = MBP\AdminMenu::all_settings();
?>
<div class="wrap mbp-wrap mbp-s3-explorer">
    <h1>
        <span class="dashicons dashicons-cloud"></span> S3 Explorer
        <?php if ($s3_configured) : ?>
        <span class="mbp-badge mbp-badge-green" style="font-size:0.6em;vertical-align:middle;margin-left:8px;">
            <?php echo esc_html($cfg['s3_bucket']); ?> @ <?php echo esc_html(parse_url($cfg['s3_endpoint'], PHP_URL_HOST)); ?>
        </span>
        <?php endif; ?>
    </h1>

    <?php if (!$s3_configured) : ?>
    <div class="mbp-notice mbp-notice-error">
        <p><strong>S3 no configurado.</strong> Ve a <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-settings'); ?>">Configuracion</a> para configurar tus credenciales S3.</p>
    </div>
    <?php else : ?>

    <!-- Toolbar -->
    <div class="mbp-s3-toolbar">
        <div class="mbp-s3-breadcrumb" id="mbp-s3-breadcrumb">
            <button class="button button-small mbp-s3-nav-root" data-prefix="">
                <span class="dashicons dashicons-cloud"></span> Raiz
            </button>
            <span id="mbp-s3-breadcrumb-path"></span>
        </div>

        <div class="mbp-s3-actions">
            <button id="mbp-s3-create-folder-btn" class="button button-secondary">
                <span class="dashicons dashicons-plus"></span> Nueva Carpeta
            </button>
            <button id="mbp-s3-refresh" class="button button-secondary">
                <span class="dashicons dashicons-update"></span> Actualizar
            </button>
        </div>
    </div>

    <!-- Modal crear carpeta -->
    <div id="mbp-s3-folder-modal" style="display:none;">
        <div class="mbp-modal-bg"></div>
        <div class="mbp-modal-box mbp-modal-small">
            <h3>Crear Nueva Carpeta</h3>
            <p>
                <input type="text" id="mbp-s3-new-folder" class="regular-text" placeholder="nombre-de-carpeta" style="width:100%;">
            </p>
            <p>
                <button id="mbp-s3-folder-confirm" class="button button-primary">Crear</button>
                <button id="mbp-s3-folder-cancel" class="button button-secondary">Cancelar</button>
            </p>
        </div>
    </div>

    <!-- Tabla de objetos -->
    <table class="widefat mbp-table" id="mbp-s3-table">
        <thead>
            <tr>
                <th width="40"></th>
                <th>Nombre</th>
                <th>Tamano</th>
                <th>Fecha</th>
                <th width="100">Acciones</th>
            </tr>
        </thead>
        <tbody id="mbp-s3-tbody">
            <tr>
                <td colspan="5" class="mbp-empty">Cargando...</td>
            </tr>
        </tbody>
    </table>

    <div class="mbp-s3-info" style="margin-top:15px;color:#646970;font-size:.9em;">
        <span class="dashicons dashicons-info-outline" style="font-size:16px;width:16px;height:16px;vertical-align:middle;"></span>
        En S3 las carpetas son objetos vacios con terminacion "/". Puedes crear carpetas, navegar y eliminar objetos desde aqui.
    </div>

    <?php endif; ?>
</div>
