# MySQL Backup Pro v2.1 - Guia de Instalacion Paso a Paso

## Requisitos Previos

| Requisito | Version minima |
|-----------|---------------|
| WordPress | 5.8 |
| PHP | 7.4 (compatible con 8.4+) |
| MySQL/MariaDB | 5.7+ |
| Extensiones PHP | `mysqli`, `openssl`, `curl`, `zlib` (gzip) |

> **NO necesitas instalar Composer ni el AWS SDK.** Este plugin incluye un cliente S3 nativo que funciona con Contabo, AWS, MinIO, Wasabi, DigitalOcean Spaces y cualquier servicio compatible S3.

---

## Paso 1: Instalar el Plugin en WordPress

### Opcion A - Subir ZIP (Recomendado)

1. Ve a tu panel de WordPress: **Plugins > Anadir nuevo > Subir plugin**
2. Haz clic en **Seleccionar archivo** y elige `mysql-backup-pro.zip`
3. Pulsa **Instalar ahora**
4. Tras la instalacion, haz clic en **Activar plugin**

### Opcion B - FTP / SFTP

1. Extrae el archivo `mysql-backup-pro.zip` en tu computadora
2. Sube la carpeta `mysql-backup-pro` a `/wp-content/plugins/`
3. Ve a WordPress: **Plugins** y pulsa **Activar** en "MySQL Backup Pro"

### Opcion C - WP-CLI (para desarrolladores)

```bash
cd /ruta/a/wordpress/wp-content/plugins
unzip mysql-backup-pro.zip
wp plugin activate mysql-backup-pro
```

---

## Paso 2: Verificar Requisitos del Servidor

Despues de activar, el plugin creara automaticamente:
- Una tabla en tu base de datos: `{prefijo}_mbp_backups`
- Una carpeta protegida: `wp-content/mysql-backup-pro/`

### Verificar extensiones PHP

En tu servidor, verifica que estas extensiones esten activas:

```bash
php -m | grep -iE 'mysqli|openssl|curl|zlib'
```

Deberias ver al menos estas 4 extensiones listadas. Si falta alguna, contacta a tu proveedor de hosting o habilitarlas en `php.ini`:

```ini
extension=mysqli
extension=openssl
extension=curl
extension=zlib
```

> **Contabo:** En VPS de Contabo, las extensiones suelen venir activadas por defecto con PHP 8.x.

---

## Paso 3: Configurar el Bucket S3 (Contabo)

### 3.1 Obtener tus credenciales de Contabo

1. Inicia sesion en tu **Panel de Control de Contabo**
2. Ve a la seccion **Object Storage** en el menu izquierdo
3. Haz clic en **Go to Object Storage Panel**
4. Navega a **Account > Security & Access**
5. Copia tu **Access Key** y tu **Secret Key**
6. Anota el nombre de tu **bucket** (ej: `backup-gestlife`)

### 3.2 Configurar en el plugin

1. En WordPress, ve a **MySQL Backup Pro > Configuracion**
2. Seccion **Configuracion S3 (Contabo / AWS / MinIO)**:

| Campo | Valor para Contabo | Ejemplo |
|-------|-------------------|---------|
| **Endpoint URL** | `https://eu2.contabostorage.com` | Ajusta segun tu region |
| **Region** | `default` | Siempre `default` para Contabo |
| **Nombre del Bucket** | Tu bucket | `backup-gestlife` |
| **Access Key** | Tu Access Key | (copia del panel) |
| **Secret Key** | Tu Secret Key | (copia del panel) |
| **Path Style** | Activado | Obligatorio para Contabo |

3. Haz clic en **Probar Conexion S3**
4. Si dice **"Conexion exitosa"**, pulsa **Guardar Configuracion**

### Endpoints de Contabo segun region

| Region | Endpoint |
|--------|----------|
| EU (Alemania) | `https://eu2.contabostorage.com` |
| US Central | `https://usc1.contabostorage.com` |
| ASIA (Singapur) | `https://sin1.contabostorage.com` |

---

## Paso 4: Configurar Frecuencia de Backups y Notificaciones

En la seccion **Configuracion General**:

| Campo | Recomendacion |
|-------|--------------|
| Backups Automaticos | Activado |
| Frecuencia | `Diario` (o segun necesidad) |
| Hora | `02:00` (madrugada, menos trafico) |
| Compresion Gzip | Activado |
| Retencion | `10` (conserva los ultimos 10 backups) |

En la seccion **Notificaciones por Email**:

| Campo | Recomendacion |
|-------|--------------|
| Email de Notificacion | Tu correo para recibir alertas |
| Plugin SMTP | Instala WP Mail SMTP si los correos no llegan |

Haz clic en **Guardar Configuracion**.

---

## Paso 5: Realizar un Backup de Prueba

1. Ve a **MySQL Backup Pro > Backups**
2. Pulsa **Ejecutar Backup Ahora**
3. Espera a que termine (aparecera una barra de progreso)
4. Al finalizar, veras el backup en la lista con:
   - Tamano del archivo
   - Numero de tablas y filas
   - Icono verde de S3 (si subio correctamente)

### Si no sube a S3 automaticamente

Si el backup se creo pero no se subio a S3, veras un icono amarillo "Local". Puedes:
1. Revisar la configuracion S3 en Configuracion
2. Hacer clic en el boton **Subir a S3** (nube con flecha arriba) en la fila del backup

### Verificar en Contabo

1. Ve a tu panel de Object Storage de Contabo
2. Revisa la carpeta `mysql-backups/AAAA/MM/`
3. Deberias ver el archivo `.sql.gz` subido

### Verificar integridad con WP Users

1. Ve a **MySQL Backup Pro > WP Users (Test)**
2. Revisa que los usuarios mostrados coincidan con tu sitio
3. Descarga el archivo SQL del backup
4. Abre el archivo y busca `INSERT INTO wp_users` para confirmar que los datos estan completos

---

## Paso 6: Configurar WP Cron (Importante para Hostings)

Para que los backups automaticos funcionen, WordPress necesita el sistema Cron.

### Opcion A - WP Cron nativo (la mayoria de hostings)

Funciona automaticamente sin configuracion adicional.

### Opcion B - Cron del sistema operativo (mas confiable)

Si tu hosting tiene problemas con WP Cron, configura un cron externo:

```bash
# Editar crontab
crontab -e

# Anadir esta linea para ejecutar cada hora:
0 * * * * wget -q -O - https://TU-DOMINIO.com/wp-cron.php?doing_wp_cron >/dev/null 2>&1
```

Y desactiva WP Cron en `wp-config.php`:

```php
define('DISABLE_WP_CRON', true);
```

---

## Solucion de Problemas

### "No se pudo inicializar el cliente S3"

**Causa:** El endpoint esta vacio o las credenciales son incorrectas.
**Solucion:**
1. Verifica que el campo **Endpoint URL** tenga valor (ej: `https://eu2.contabostorage.com`)
2. Verifica Access Key y Secret Key
3. Asegurate de que **Path Style** este activado
4. Prueba la conexion de nuevo

### Los backups no se ejecutan automaticamente

**Causa:** WP Cron no esta funcionando.
**Solucion:**
1. Instala el plugin "WP Crontrol" para ver los cron jobs
2. Verifica que existe el evento `mbp_run_cron_backup`
3. Configura un cron externo (ver Paso 6)

### Error de memoria al hacer backup

**Solucion:** Aumenta el limite en `wp-config.php`:

```php
define('WP_MEMORY_LIMIT', '512M');
ini_set('max_execution_time', '600');
```

### No llegan los correos de notificacion

**Causa:** Tu servidor no tiene configurado el envio de correos.
**Solucion:**
1. Verifica que el campo **Email de Notificacion** tiene un correo valido
2. Instala un plugin SMTP como **WP Mail SMTP** para enviar correos
3. Ve a Configuracion > MySQL Backup Pro y haz clic en **Enviar Email de Prueba**
4. Revisa la carpeta de spam

### Error "cURL error"

**Causa:** La extension cURL de PHP no esta activada.
**Solucion:** Activa `extension=curl` en tu `php.ini` y reinicia el servidor web.

### La tabla de backups no existe

**Causa:** El plugin no se activo correctamente.
**Solucion:**
1. Desactiva el plugin
2. Activalo de nuevo
3. Si persiste, crea la tabla manualmente en phpMyAdmin:

```sql
CREATE TABLE IF NOT EXISTS `wp_mbp_backups` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `s3_key` varchar(500) DEFAULT NULL,
  `s3_bucket` varchar(255) DEFAULT NULL,
  `s3_endpoint` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `tables_list` text DEFAULT NULL,
  `rows_count` bigint(20) DEFAULT 0,
  `status` varchar(50) DEFAULT 'pending',
  `backup_type` varchar(50) DEFAULT 'manual',
  `error_msg` text DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## Configuracion para Otros Proveedores S3

### AWS S3
| Campo | Valor |
|-------|-------|
| Endpoint | `https://s3.us-east-1.amazonaws.com` (o tu region) |
| Region | `us-east-1` (o tu region) |
| Path Style | Desactivado |

### MinIO
| Campo | Valor |
|-------|-------|
| Endpoint | `https://tu-minio.com:9000` |
| Region | `us-east-1` |
| Path Style | Activado |

### Wasabi
| Campo | Valor |
|-------|-------|
| Endpoint | `https://s3.wasabisys.com` |
| Region | `us-east-1` |
| Path Style | Activado |

---

## Actualizar el Plugin

1. Desactiva el plugin actual
2. Borra la carpeta `mysql-backup-pro` de `/wp-content/plugins/`
3. Sube la nueva version
4. Activa el plugin

> **Nota:** Tus configuraciones y backups previos se conservan en la base de datos.

---

## Changelog v2.1

- **Corregido:** Bug critico en S3 donde `curl_close` se ejecutaba antes de `curl_getinfo`
- **Corregido:** Falta de `global $wpdb` en la pagina de backups
- **Nuevo:** Boton "Subir a S3" para backups locales que no se subieron automaticamente
- **Nuevo:** Boton "Actualizar Lista" que recarga los backups sin refrescar la pagina
- **Nuevo:** Sistema de verificacion de tabla con mensajes de error visibles
- **Nuevo:** Boton "Enviar Email de Prueba" en la configuracion
- **Nuevo:** Notices de advertencia en el admin si falta configuracion
- **Mejorado:** Manejo de errores en subida a S3 con mensajes descriptivos
- **Mejorado:** Sistema de notificaciones con logging en error_log
