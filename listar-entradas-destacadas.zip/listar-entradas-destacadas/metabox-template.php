<p>
  <input type="checkbox" id="led_es_destacado" name="led_es_destacado" <?php echo $es_destacado ?>>
  <label for="led_es_destacado">Destacar esta entrada</label>
</p>