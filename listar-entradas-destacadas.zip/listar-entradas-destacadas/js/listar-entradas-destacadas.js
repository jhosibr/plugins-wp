jQuery(document).ready(function($) {
  // Código para mostrar las publicaciones destacadas
});