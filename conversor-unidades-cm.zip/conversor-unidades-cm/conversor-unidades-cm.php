<?php
/**
 * Plugin Name: Conversor Unidades CM
 * Description: Plugin que permite convertir unidades de longitud, medida, peso y volumen en tu sitio web utilizando un shortcode.
 * Version: 1.0
 * Author: Jhosimar Ocampo
 */

function conversor_unidades_cm_shortcode() {
    // Agregar estilos CSS al plugin
    wp_enqueue_style( 'conversor-unidades-cm-styles', plugin_dir_url( __FILE__ ) . 'conversor-unidades-cm.css' );

    ob_start();
    ?>
    <form action="" method="post" id="conversor-unidades-cm-form">
        <label for="valor">Valor:</label>
        <input type="text" name="valor" id="valor">
        <br>
        <label for="unidad_origen">Unidad origen:</label>
        <select name="unidad_origen" id="unidad_origen">
            <option value="cm">Centímetros</option>
            <option value="m">Metros</option>
            <option value="km">Kilómetros</option>
            <option value="in">Pulgadas</option>
            <option value="ft">Pies</option>
            <option value="yd">Yardas</option>
            <option value="mi">Millas</option>
            <option value="g">Gramos</option>
            <option value="kg">Kilogramos</option>
            <option value="oz">Onzas</option>
            <option value="lb">Libras</option>
            <option value="ml">Mililitros</option>
            <option value="l">Litros</option>
            <option value="gal">Galones</option>
        </select>
        <br>
        <label for="unidad_destino">Unidad destino:</label>
        <select name="unidad_destino" id="unidad_destino">
            <option value="cm">Centímetros</option>
            <option value="m">Metros</option>
            <option value="km">Kilómetros</option>
            <option value="in">Pulgadas</option>
            <option value="ft">Pies</option>
            <option value="yd">Yardas</option>
            <option value="mi">Millas</option>
            <option value="g">Gramos</option>
            <option value="kg">Kilogramos</option>
            <option value="oz">Onzas</option>
            <option value="lb">Libras</option>
            <option value="ml">Mililitros</option>
            <option value="l">Litros</option>
            <option value="gal">Galones</option>
        </select>
        <br>
        <button type="submit">Convertir</button>
    </form>
    <?php

    // código para convertir unidades

    return ob_get_clean();
}
add_shortcode('conversor_unidades_cm', 'conversor_unidades_cm_shortcode');