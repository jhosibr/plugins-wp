<?php
/**
 * Plugin Name: DB Backup S3
 * Plugin URI:  https://github.com/gestlifedev/plugin-wpddress-bakups
 * Description: Realiza backups automáticos de la base de datos MySQL y los sube a un bucket S3 compatible (Contabo, AWS, etc.). Incluye panel de configuración, listado de backups y visor de tabla wp_users para pruebas.
 * Version:     1.0.0
 * Author:      GestLife Dev
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: db-backup-s3
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DBBS3_VERSION', '1.0.0');
define('DBBS3_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DBBS3_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DBBS3_BACKUP_DIR', WP_CONTENT_DIR . '/db-backup-s3-temp/');

// Crear directorio temporal si no existe
if (!file_exists(DBBS3_BACKUP_DIR)) {
    wp_mkdir_p(DBBS3_BACKUP_DIR);
    file_put_contents(DBBS3_BACKUP_DIR . '.htaccess', "deny from all\n");
    file_put_contents(DBBS3_BACKUP_DIR . 'index.php', '<?php // Silence is golden');
}

// Tabla para registrar backups
function dbbs3_activate_plugin() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'db_backup_s3_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        file_name varchar(255) NOT NULL,
        file_size bigint(20) NOT NULL DEFAULT 0,
        file_path varchar(500) NOT NULL,
        s3_key varchar(500) DEFAULT NULL,
        s3_url varchar(500) DEFAULT NULL,
        status varchar(50) NOT NULL DEFAULT 'pending',
        error_message text DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        completed_at datetime DEFAULT NULL,
        PRIMARY KEY (id)
    ) {$charset_collate};";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Programar el evento CRON si no está programado
    if (!wp_next_scheduled('dbbs3_scheduled_backup')) {
        $frequency = get_option('dbbs3_frequency', 'daily');
        wp_schedule_event(time(), $frequency, 'dbbs3_scheduled_backup');
    }
}
register_activation_hook(__FILE__, 'dbbs3_activate_plugin');

function dbbs3_deactivate_plugin() {
    wp_clear_scheduled_hook('dbbs3_scheduled_backup');
}
register_deactivation_hook(__FILE__, 'dbbs3_deactivate_plugin');

// Reprogramar CRON cuando cambia la frecuencia
function dbbs3_reschedule_cron($old_value, $value, $option) {
    wp_clear_scheduled_hook('dbbs3_scheduled_backup');
    wp_schedule_event(time(), $value, 'dbbs3_scheduled_backup');
}
add_action('update_option_dbbs3_frequency', 'dbbs3_reschedule_cron', 10, 3);

// Incluir clases
require_once DBBS3_PLUGIN_DIR . 'includes/class-s3-client.php';
require_once DBBS3_PLUGIN_DIR . 'includes/class-backup-manager.php';
require_once DBBS3_PLUGIN_DIR . 'includes/class-admin.php';

// Inicializar
function dbbs3_init() {
    DBBS3_Admin::instance();
    DBBS3_Backup_Manager::instance();
}
add_action('plugins_loaded', 'dbbs3_init');

// Hook para el backup programado
add_action('dbbs3_scheduled_backup', array('DBBS3_Backup_Manager', 'run_scheduled_backup'));

// AJAX handlers
add_action('wp_ajax_dbbs3_test_connection', array('DBBS3_Admin', 'ajax_test_connection'));
add_action('wp_ajax_dbbs3_run_backup_now', array('DBBS3_Admin', 'ajax_run_backup_now'));
add_action('wp_ajax_dbbs3_delete_backup', array('DBBS3_Admin', 'ajax_delete_backup'));
add_action('wp_ajax_dbbs3_download_backup', array('DBBS3_Admin', 'ajax_download_backup'));
add_action('wp_ajax_dbbs3_get_backup_url', array('DBBS3_Admin', 'ajax_get_backup_url'));
