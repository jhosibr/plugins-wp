<?php
/**
 * Panel de Administración
 */
class DBBS3_Admin {

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Agrega menú al admin
     */
    public function add_menu() {
        add_menu_page(
            'DB Backup S3',
            'DB Backup S3',
            'manage_options',
            'db-backup-s3',
            array($this, 'render_dashboard'),
            'dashicons-cloud-upload',
            81
        );

        add_submenu_page(
            'db-backup-s3',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'db-backup-s3',
            array($this, 'render_dashboard')
        );

        add_submenu_page(
            'db-backup-s3',
            'Configuración',
            'Configuración',
            'manage_options',
            'db-backup-s3-config',
            array($this, 'render_config')
        );

        add_submenu_page(
            'db-backup-s3',
            'Historial de Backups',
            'Historial de Backups',
            'manage_options',
            'db-backup-s3-history',
            array($this, 'render_history')
        );

        add_submenu_page(
            'db-backup-s3',
            'Tabla wp_users (Pruebas)',
            'wp_users (Pruebas)',
            'manage_options',
            'db-backup-s3-users',
            array($this, 'render_users')
        );
    }

    /**
     * Carga CSS y JS
     */
    public function enqueue_assets($hook) {
        if (strpos($hook, 'db-backup-s3') === false) {
            return;
        }
        wp_enqueue_style('dbbs3-admin', DBBS3_PLUGIN_URL . 'assets/css/admin.css', array(), DBBS3_VERSION);
        wp_enqueue_script('dbbs3-admin', DBBS3_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), DBBS3_VERSION, true);
        wp_localize_script('dbbs3-admin', 'dbbs3_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('dbbs3_nonce'),
        ));
    }

    /**
     * Registra opciones
     */
    public function register_settings() {
        register_setting('dbbs3_settings', 'dbbs3_provider');
        register_setting('dbbs3_settings', 'dbbs3_endpoint');
        register_setting('dbbs3_settings', 'dbbs3_access_key');
        register_setting('dbbs3_settings', 'dbbs3_secret_key');
        register_setting('dbbs3_settings', 'dbbs3_region');
        register_setting('dbbs3_settings', 'dbbs3_bucket');
        register_setting('dbbs3_settings', 'dbbs3_frequency');
        register_setting('dbbs3_settings', 'dbbs3_retention_days');
        register_setting('dbbs3_settings', 'dbbs3_keep_local');

        // Valores por defecto
        add_option('dbbs3_provider', 'contabo');
        add_option('dbbs3_frequency', 'daily');
        add_option('dbbs3_retention_days', 30);
        add_option('dbbs3_keep_local', 'no');
    }

    /**
     * Dashboard principal
     */
    public function render_dashboard() {
        $config = DBBS3_Backup_Manager::instance()->get_config();
        $is_configured = DBBS3_Backup_Manager::instance()->is_configured($config);
        $next_run = wp_next_scheduled('dbbs3_scheduled_backup');
        $frequency = get_option('dbbs3_frequency', 'daily');
        $frequencies = $this->get_frequency_options();
        $retention = get_option('dbbs3_retention_days', 30);

        // Estadísticas
        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';
        $total_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        $success_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'success'");
        $failed_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'failed'");
        $last_backup = $wpdb->get_row("SELECT * FROM {$table_name} WHERE status = 'success' ORDER BY created_at DESC LIMIT 1");
        ?>
        <div class="wrap dbbs3-wrap">
            <h1><span class="dashicons dashicons-cloud-upload"></span> DB Backup S3</h1>

            <?php if (!$is_configured): ?>
            <div class="dbbs3-alert dbbs3-alert-warning">
                <strong>Atención:</strong> El plugin no está configurado. Ve a <a href="<?php echo admin_url('admin.php?page=db-backup-s3-config'); ?>">Configuración</a> para ingresar los datos de tu bucket S3.
            </div>
            <?php endif; ?>

            <div class="dbbs3-dashboard">
                <!-- Tarjetas de estadísticas -->
                <div class="dbbs3-stats-grid">
                    <div class="dbbs3-stat-card dbbs3-stat-success">
                        <span class="dbbs3-stat-icon dashicons dashicons-yes-alt"></span>
                        <div class="dbbs3-stat-content">
                            <h3><?php echo esc_html($success_backups); ?></h3>
                            <p>Backups Exitosos</p>
                        </div>
                    </div>
                    <div class="dbbs3-stat-card dbbs3-stat-danger">
                        <span class="dbbs3-stat-icon dashicons dashicons-warning"></span>
                        <div class="dbbs3-stat-content">
                            <h3><?php echo esc_html($failed_backups); ?></h3>
                            <p>Backups Fallidos</p>
                        </div>
                    </div>
                    <div class="dbbs3-stat-card dbbs3-stat-info">
                        <span class="dbbs3-stat-icon dashicons dashicons-backup"></span>
                        <div class="dbbs3-stat-content">
                            <h3><?php echo esc_html($total_backups); ?></h3>
                            <p>Total Backups</p>
                        </div>
                    </div>
                    <div class="dbbs3-stat-card dbbs3-stat-primary">
                        <span class="dbbs3-stat-icon dashicons dashicons-calendar-alt"></span>
                        <div class="dbbs3-stat-content">
                            <h3><?php echo esc_html($frequencies[$frequency]); ?></h3>
                            <p>Frecuencia</p>
                        </div>
                    </div>
                </div>

                <div class="dbbs3-columns">
                    <!-- Columna izquierda -->
                    <div class="dbbs3-column-main">
                        <div class="dbbs3-card">
                            <h2>Último Backup</h2>
                            <?php if ($last_backup): ?>
                                <div class="dbbs3-last-backup">
                                    <p><strong>Archivo:</strong> <code><?php echo esc_html($last_backup->file_name); ?></code></p>
                                    <p><strong>Tamaño:</strong> <?php echo esc_html(size_format($last_backup->file_size)); ?></p>
                                    <p><strong>Fecha:</strong> <?php echo esc_html(date('d/m/Y H:i:s', strtotime($last_backup->created_at))); ?></p>
                                    <p><strong>Estado:</strong> <span class="dbbs3-badge dbbs3-badge-success">Exitoso</span></p>
                                </div>
                            <?php else: ?>
                                <p class="dbbs3-empty">Aún no se ha realizado ningún backup.</p>
                            <?php endif; ?>
                        </div>

                        <div class="dbbs3-card">
                            <h2>Próximo Backup Programado</h2>
                            <?php if ($next_run): ?>
                                <p><?php echo esc_html(date('d/m/Y H:i:s', $next_run)); ?></p>
                                <p class="dbbs3-text-muted">Frecuencia: <?php echo esc_html($frequencies[$frequency]); ?></p>
                            <?php else: ?>
                                <p class="dbbs3-empty">No hay backups programados.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Columna derecha - Acciones -->
                    <div class="dbbs3-column-side">
                        <div class="dbbs3-card">
                            <h2>Acciones Rápidas</h2>
                            <button type="button" class="button button-primary button-hero dbbs3-btn-block" id="dbbs3-run-backup-now" <?php echo !$is_configured ? 'disabled' : ''; ?>>
                                <span class="dashicons dashicons-cloud-upload"></span> Ejecutar Backup Ahora
                            </button>
                            <div id="dbbs3-backup-result"></div>
                        </div>

                        <div class="dbbs3-card">
                            <h2>Estado de Conexión</h2>
                            <?php if ($is_configured): ?>
                                <p><strong>Bucket:</strong> <code><?php echo esc_html($config['bucket']); ?></code></p>
                                <p><strong>Endpoint:</strong> <code><?php echo esc_html($config['endpoint']); ?></code></p>
                                <p><strong>Región:</strong> <code><?php echo esc_html($config['region']); ?></code></p>
                                <p>
                                    <button type="button" class="button" id="dbbs3-test-connection">
                                        <span class="dashicons dashicons-admin-site-alt3"></span> Probar Conexión
                                    </button>
                                </p>
                                <div id="dbbs3-connection-result"></div>
                            <?php else: ?>
                                <p class="dbbs3-empty">No configurado.</p>
                            <?php endif; ?>
                        </div>

                        <div class="dbbs3-card">
                            <h2>Info de la Base de Datos</h2>
                            <p><strong>Base de datos:</strong> <code><?php echo esc_html(DB_NAME); ?></code></p>
                            <p><strong>Servidor:</strong> <code><?php echo esc_html(DB_HOST); ?></code></p>
                            <p><strong>Tablas:</strong>
                                <?php
                                $tables = $wpdb->get_col("SHOW TABLES");
                                echo esc_html(count($tables));
                                ?> tablas
                            </p>
                            <p><strong>Tamaño aproximado:</strong>
                                <?php
                                $size = $wpdb->get_var("SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = '" . DB_NAME . "'");
                                echo esc_html(size_format($size));
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Página de configuración
     */
    public function render_config() {
        $providers = array(
            'contabo'      => 'Contabo Object Storage',
            'aws'          => 'Amazon Web Services (AWS)',
            'digitalocean' => 'DigitalOcean Spaces',
            'wasabi'       => 'Wasabi',
            'other'        => 'Otro (Personalizado)',
        );

        $regions = array(
            'default'    => 'Default / Auto',
            'eu2'        => 'EU (eu2.contabostorage.com)',
            'us-central' => 'US Central',
            'us-east-1'  => 'US East (N. Virginia)',
            'us-west-1'  => 'US West (N. California)',
            'eu-west-1'  => 'EU (Ireland)',
            'eu-central-1' => 'EU (Frankfurt)',
        );

        $frequencies = $this->get_frequency_options();
        $retention_options = array(7 => '7 días', 14 => '14 días', 30 => '30 días', 60 => '60 días', 90 => '90 días', 0 => 'Sin límite (conservar todos)');
        ?>
        <div class="wrap dbbs3-wrap">
            <h1><span class="dashicons dashicons-admin-generic"></span> Configuración del Bucket S3</h1>

            <form method="post" action="options.php" class="dbbs3-form">
                <?php settings_fields('dbbs3_settings'); ?>

                <div class="dbbs3-form-section">
                    <h2>Proveedor S3</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="dbbs3_provider">Proveedor S3</label></th>
                            <td>
                                <select name="dbbs3_provider" id="dbbs3_provider" class="regular-text">
                                    <?php foreach ($providers as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>" <?php selected(get_option('dbbs3_provider', 'contabo'), $key); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Selecciona tu proveedor de almacenamiento S3.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_endpoint">Endpoint (URL Base)</label></th>
                            <td>
                                <input type="url" name="dbbs3_endpoint" id="dbbs3_endpoint" value="<?php echo esc_attr(get_option('dbbs3_endpoint', '')); ?>" class="regular-text" placeholder="https://eu2.contabostorage.com">
                                <p class="description">URL base del endpoint S3. Ejemplo: https://eu2.contabostorage.com</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_region">Región</label></th>
                            <td>
                                <select name="dbbs3_region" id="dbbs3_region" class="regular-text">
                                    <?php foreach ($regions as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>" <?php selected(get_option('dbbs3_region', 'eu2'), $key); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Región donde se encuentra tu bucket.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="dbbs3-form-section">
                    <h2>Credenciales</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="dbbs3_access_key">Access Key</label></th>
                            <td>
                                <input type="text" name="dbbs3_access_key" id="dbbs3_access_key" value="<?php echo esc_attr(get_option('dbbs3_access_key', '')); ?>" class="regular-text" autocomplete="off">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_secret_key">Secret Key</label></th>
                            <td>
                                <input type="password" name="dbbs3_secret_key" id="dbbs3_secret_key" value="<?php echo esc_attr(get_option('dbbs3_secret_key', '')); ?>" class="regular-text" autocomplete="off">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_bucket">Nombre del Bucket</label></th>
                            <td>
                                <input type="text" name="dbbs3_bucket" id="dbbs3_bucket" value="<?php echo esc_attr(get_option('dbbs3_bucket', '')); ?>" class="regular-text" placeholder="mi-backup-bucket">
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="dbbs3-form-section">
                    <h2>Programación y Retención</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="dbbs3_frequency">Frecuencia de Backups</label></th>
                            <td>
                                <select name="dbbs3_frequency" id="dbbs3_frequency" class="regular-text">
                                    <?php foreach ($frequencies as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>" <?php selected(get_option('dbbs3_frequency', 'daily'), $key); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Con qué frecuencia se ejecutarán los backups automáticos.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_retention_days">Retención</label></th>
                            <td>
                                <select name="dbbs3_retention_days" id="dbbs3_retention_days" class="regular-text">
                                    <?php foreach ($retention_options as $key => $label): ?>
                                        <option value="<?php echo esc_attr($key); ?>" <?php selected(get_option('dbbs3_retention_days', 30), $key); ?>>
                                            <?php echo esc_html($label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Los backups más antiguos serán eliminados automáticamente del S3.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="dbbs3_keep_local">Conservar copia local</label></th>
                            <td>
                                <select name="dbbs3_keep_local" id="dbbs3_keep_local" class="regular-text">
                                    <option value="no" <?php selected(get_option('dbbs3_keep_local', 'no'), 'no'); ?>>No, eliminar después de subir</option>
                                    <option value="yes" <?php selected(get_option('dbbs3_keep_local', 'no'), 'yes'); ?>>Sí, mantener copia local</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="dbbs3-form-actions">
                    <button type="button" class="button" id="dbbs3-test-connection-config">
                        <span class="dashicons dashicons-admin-site-alt3"></span> Probar Conexión S3
                    </button>
                    <span id="dbbs3-config-test-result"></span>
                </div>

                <?php submit_button('Guardar Configuración', 'primary', 'submit', true, array('class' => 'button button-primary button-hero')); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Página de historial
     */
    public function render_history() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';

        // Paginación
        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;

        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        $backups = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT {$offset}, {$per_page}");

        $total_pages = ceil($total_items / $per_page);
        ?>
        <div class="wrap dbbs3-wrap">
            <h1><span class="dashicons dashicons-backup"></span> Historial de Backups</h1>

            <?php if (empty($backups)): ?>
                <div class="dbbs3-empty-state">
                    <span class="dashicons dashicons-cloud"></span>
                    <h2>No hay backups registrados</h2>
                    <p>Los backups aparecerán aquí una vez que se ejecuten. Puedes ejecutar uno manualmente desde el Dashboard.</p>
                    <a href="<?php echo admin_url('admin.php?page=db-backup-s3'); ?>" class="button button-primary">Ir al Dashboard</a>
                </div>
            <?php else: ?>
                <div class="dbbs3-table-wrap">
                    <table class="wp-list-table widefat fixed striped dbbs3-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Archivo</th>
                                <th>Tamaño</th>
                                <th>Estado</th>
                                <th>Fecha de Creación</th>
                                <th>Completado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backups as $backup): ?>
                                <tr data-id="<?php echo esc_attr($backup->id); ?>">
                                    <td><?php echo esc_html($backup->id); ?></td>
                                    <td><code><?php echo esc_html($backup->file_name); ?></code></td>
                                    <td><?php echo $backup->file_size > 0 ? esc_html(size_format($backup->file_size)) : '-'; ?></td>
                                    <td>
                                        <?php if ($backup->status === 'success'): ?>
                                            <span class="dbbs3-badge dbbs3-badge-success">Exitoso</span>
                                        <?php elseif ($backup->status === 'failed'): ?>
                                            <span class="dbbs3-badge dbbs3-badge-danger">Fallido</span>
                                            <?php if (!empty($backup->error_message)): ?>
                                                <span class="dbbs3-tooltip" title="<?php echo esc_attr($backup->error_message); ?>">
                                                    <span class="dashicons dashicons-info-outline"></span>
                                                </span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="dbbs3-badge dbbs3-badge-warning"><?php echo esc_html($backup->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($backup->created_at))); ?></td>
                                    <td>
                                        <?php echo $backup->completed_at ? esc_html(date('d/m/Y H:i:s', strtotime($backup->completed_at))) : '-'; ?>
                                    </td>
                                    <td>
                                        <?php if ($backup->status === 'success' && !empty($backup->s3_key)): ?>
                                            <button type="button" class="button button-small dbbs3-download-btn" data-id="<?php echo esc_attr($backup->id); ?>" data-key="<?php echo esc_attr($backup->s3_key); ?>">
                                                <span class="dashicons dashicons-download"></span> Descargar
                                            </button>
                                        <?php endif; ?>
                                        <?php if (file_exists($backup->file_path)): ?>
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=db-backup-s3-history&dbbs3_download=' . $backup->id . '&_wpnonce=' . wp_create_nonce('dbbs3_download_' . $backup->id))); ?>" class="button button-small">
                                                <span class="dashicons dashicons-media-document"></span> Local
                                            </a>
                                        <?php endif; ?>
                                        <button type="button" class="button button-small dbbs3-delete-btn" data-id="<?php echo esc_attr($backup->id); ?>">
                                            <span class="dashicons dashicons-trash"></span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_pages > 1): ?>
                <div class="tablenav">
                    <div class="tablenav-pages">
                        <span class="displaying-num"><?php echo esc_html($total_items); ?> elementos</span>
                        <span class="pagination-links">
                            <?php if ($current_page > 1): ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=db-backup-s3-history&paged=' . ($current_page - 1))); ?>" class="prev-page button">&lsaquo;</a>
                            <?php endif; ?>
                            <span class="paging-input">
                                <span class="tablenav-paging-text"><?php echo esc_html($current_page); ?> de <?php echo esc_html($total_pages); ?></span>
                            </span>
                            <?php if ($current_page < $total_pages): ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=db-backup-s3-history&paged=' . ($current_page + 1))); ?>" class="next-page button">&rsaquo;</a>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Página de wp_users para pruebas
     */
    public function render_users() {
        global $wpdb;

        // Verificar que la tabla wp_users existe
        $users_table = $wpdb->prefix . 'users';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$users_table}'") === $users_table;

        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;

        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

        $where = '';
        if (!empty($search)) {
            $where = $wpdb->prepare(" WHERE user_login LIKE %s OR user_email LIKE %s OR display_name LIKE %s",
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%'
            );
        }

        $total_items = $wpdb->get_var("SELECT COUNT(*) FROM {$users_table} {$where}");
        $users = $wpdb->get_results("SELECT ID, user_login, user_email, display_name, user_registered FROM {$users_table} {$where} ORDER BY ID DESC LIMIT {$offset}, {$per_page}");
        $total_pages = ceil($total_items / $per_page);
        ?>
        <div class="wrap dbbs3-wrap">
            <h1><span class="dashicons dashicons-groups"></span> Tabla wp_users (Modo Pruebas)</h1>

            <div class="dbbs3-alert dbbs3-alert-info">
                <strong>Modo Pruebas:</strong> Esta vista muestra la tabla <code>wp_users</code> de tu base de datos. 
                Úsala para verificar que los backups contienen los datos correctos. 
                También puedes hacer clic en "Exportar CSV" para descargar los datos.
            </div>

            <?php if (!$table_exists): ?>
                <div class="dbbs3-alert dbbs3-alert-danger">
                    La tabla <code><?php echo esc_html($users_table); ?></code> no existe.
                </div>
            <?php else: ?>
                <!-- Búsqueda -->
                <form method="get" class="dbbs3-search-form">
                    <input type="hidden" name="page" value="db-backup-s3-users">
                    <p class="search-box">
                        <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Buscar usuarios...">
                        <input type="submit" class="button" value="Buscar">
                    </p>
                </form>

                <!-- Estadísticas rápidas -->
                <div class="dbbs3-stats-inline">
                    <span class="dbbs3-stat">
                        <strong>Total usuarios:</strong> <?php echo esc_html($total_items); ?>
                    </span>
                    <span class="dbbs3-stat">
                        <strong>Tabla:</strong> <code><?php echo esc_html($users_table); ?></code>
                    </span>
                    <span class="dbbs3-stat">
                        <strong>Último registro:</strong>
                        <?php
                        $last = $wpdb->get_var("SELECT MAX(user_registered) FROM {$users_table}");
                        echo esc_html($last ? date('d/m/Y H:i:s', strtotime($last)) : 'N/A');
                        ?>
                    </span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=db-backup-s3-users&dbbs3_export_users=1&_wpnonce=' . wp_create_nonce('dbbs3_export_users'))); ?>" class="button">
                        <span class="dashicons dashicons-download"></span> Exportar CSV
                    </a>
                </div>

                <?php if (empty($users)): ?>
                    <div class="dbbs3-empty-state">
                        <span class="dashicons dashicons-groups"></span>
                        <h2>No hay usuarios registrados</h2>
                    </div>
                <?php else: ?>
                    <div class="dbbs3-table-wrap">
                        <table class="wp-list-table widefat fixed striped dbbs3-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Display Name</th>
                                    <th>Registrado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo esc_html($user->ID); ?></td>
                                        <td><code><?php echo esc_html($user->user_login); ?></code></td>
                                        <td><?php echo esc_html($user->user_email); ?></td>
                                        <td><?php echo esc_html($user->display_name); ?></td>
                                        <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($user->user_registered))); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($total_pages > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <span class="displaying-num"><?php echo esc_html($total_items); ?> usuarios</span>
                            <span class="pagination-links">
                                <?php if ($current_page > 1): ?>
                                    <a href="<?php echo esc_url(add_query_arg('paged', $current_page - 1)); ?>" class="prev-page button">&lsaquo;</a>
                                <?php endif; ?>
                                <span class="paging-input">
                                    <span class="tablenav-paging-text"><?php echo esc_html($current_page); ?> de <?php echo esc_html($total_pages); ?></span>
                                </span>
                                <?php if ($current_page < $total_pages): ?>
                                    <a href="<?php echo esc_url(add_query_arg('paged', $current_page + 1)); ?>" class="next-page button">&rsaquo;</a>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Opciones de frecuencia
     */
    private function get_frequency_options() {
        return array(
            'hourly'     => 'Cada hora',
            'twicedaily' => 'Dos veces al día',
            'daily'      => 'Diario',
            'weekly'     => 'Semanal',
        );
    }

    // ========== AJAX Handlers ==========

    public static function ajax_test_connection() {
        check_ajax_referer('dbbs3_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos.');
        }

        $config = DBBS3_Backup_Manager::instance()->get_config();
        if (!DBBS3_Backup_Manager::instance()->is_configured($config)) {
            wp_send_json_error('Configuración incompleta. Por completa todos los campos.');
        }

        $s3 = new DBBS3_S3_Client(
            $config['access_key'],
            $config['secret_key'],
            $config['endpoint'],
            $config['region'],
            $config['bucket']
        );

        if ($s3->test_connection()) {
            wp_send_json_success('Conexión exitosa con el bucket S3.');
        } else {
            wp_send_json_error('No se pudo conectar al bucket S3. Verifica tus credenciales y endpoint.');
        }
    }

    public static function ajax_run_backup_now() {
        check_ajax_referer('dbbs3_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos.');
        }

        $result = DBBS3_Backup_Manager::instance()->create_and_upload_backup();

        if ($result) {
            wp_send_json_success('Backup creado y subido exitosamente a S3.');
        } else {
            wp_send_json_error('El backup falló. Revisa el historial para más detalles.');
        }
    }

    public static function ajax_delete_backup() {
        check_ajax_referer('dbbs3_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos.');
        }

        $id = intval($_POST['id']);
        if (!$id) {
            wp_send_json_error('ID inválido.');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';
        $backup = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id));

        if (!$backup) {
            wp_send_json_error('Backup no encontrado.');
        }

        // Eliminar de S3
        if (!empty($backup->s3_key)) {
            $config = DBBS3_Backup_Manager::instance()->get_config();
            $s3 = new DBBS3_S3_Client(
                $config['access_key'],
                $config['secret_key'],
                $config['endpoint'],
                $config['region'],
                $config['bucket']
            );
            $s3->delete_object($backup->s3_key);
        }

        // Eliminar archivo local
        if (file_exists($backup->file_path)) {
            @unlink($backup->file_path);
        }

        // Eliminar registro
        $wpdb->delete($table_name, array('id' => $id));

        wp_send_json_success('Backup eliminado.');
    }

    public static function ajax_download_backup() {
        check_ajax_referer('dbbs3_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos.');
        }

        $s3_key = sanitize_text_field($_POST['key']);
        $config = DBBS3_Backup_Manager::instance()->get_config();

        $s3 = new DBBS3_S3_Client(
            $config['access_key'],
            $config['secret_key'],
            $config['endpoint'],
            $config['region'],
            $config['bucket']
        );

        $url = $s3->get_presigned_url($s3_key, 3600);
        wp_send_json_success(array('url' => $url));
    }

    public static function ajax_get_backup_url() {
        check_ajax_referer('dbbs3_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('No tienes permisos.');
        }

        $id = intval($_POST['id']);
        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';
        $backup = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id));

        if (!$backup || empty($backup->s3_key)) {
            wp_send_json_error('Backup no encontrado o no disponible en S3.');
        }

        $config = DBBS3_Backup_Manager::instance()->get_config();
        $s3 = new DBBS3_S3_Client(
            $config['access_key'],
            $config['secret_key'],
            $config['endpoint'],
            $config['region'],
            $config['bucket']
        );
        $url = $s3->get_presigned_url($backup->s3_key);
        wp_send_json_success(array('url' => $url));
    }
}

// Manejar descarga de archivo local
add_action('admin_init', function() {
    if (isset($_GET['dbbs3_download']) && isset($_GET['_wpnonce'])) {
        $id = intval($_GET['dbbs3_download']);
        if (!wp_verify_nonce($_GET['_wpnonce'], 'dbbs3_download_' . $id)) {
            wp_die('Nonce inválido.');
        }
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos.');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';
        $backup = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id));

        if ($backup && file_exists($backup->file_path)) {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . basename($backup->file_path) . '"');
            header('Content-Length: ' . filesize($backup->file_path));
            readfile($backup->file_path);
            exit;
        }
        wp_die('Archivo no encontrado.');
    }
});

// Exportar usuarios a CSV
add_action('admin_init', function() {
    if (isset($_GET['dbbs3_export_users']) && isset($_GET['_wpnonce'])) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'dbbs3_export_users')) {
            wp_die('Nonce inválido.');
        }
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos.');
        }

        global $wpdb;
        $users_table = $wpdb->prefix . 'users';
        $users = $wpdb->get_results("SELECT ID, user_login, user_email, display_name, user_registered, user_status FROM {$users_table} ORDER BY ID DESC", ARRAY_A);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="wp_users_export_' . date('Y-m-d_H-i-s') . '.csv"');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM para Excel

        fputcsv($output, array('ID', 'Username', 'Email', 'Display Name', 'Registered', 'Status'));
        foreach ($users as $user) {
            fputcsv($output, $user);
        }
        fclose($output);
        exit;
    }
});
