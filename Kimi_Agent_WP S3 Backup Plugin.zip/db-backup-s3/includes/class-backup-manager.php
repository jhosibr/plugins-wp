<?php
/**
 * Gestor de Backups - Crea dumps MySQL y los sube a S3
 */
class DBBS3_Backup_Manager {

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Ejecuta el backup programado por CRON
     */
    public static function run_scheduled_backup() {
        self::instance()->create_and_upload_backup();
    }

    /**
     * Crea un backup y lo sube a S3
     */
    public function create_and_upload_backup() {
        global $wpdb;

        // Verificar configuración
        $config = $this->get_config();
        if (!$this->is_configured($config)) {
            error_log('DB Backup S3: Configuracion incompleta, no se puede ejecutar el backup.');
            return false;
        }

        // Generar nombre de archivo
        $site_name = sanitize_file_name(get_bloginfo('name'));
        $timestamp = date('Y-m-d_H-i-s');
        $sql_file = DBBS3_BACKUP_DIR . $site_name . '_backup_' . $timestamp . '.sql';
        $zip_file = $sql_file . '.zip';
        $s3_key = 'backups/' . $site_name . '_backup_' . $timestamp . '.sql.zip';

        // Registrar en base de datos
        $log_id = $this->log_backup($s3_key, $zip_file, 'running');

        // Crear el dump SQL
        $dump_result = $this->create_mysql_dump($sql_file);
        if (is_wp_error($dump_result)) {
            $this->update_log($log_id, 'failed', $dump_result->get_error_message());
            return false;
        }

        // Comprimir a ZIP
        $zip_result = $this->compress_file($sql_file, $zip_file);
        if (is_wp_error($zip_result)) {
            @unlink($sql_file);
            $this->update_log($log_id, 'failed', $zip_result->get_error_message());
            return false;
        }

        // Limpiar archivo SQL original
        @unlink($sql_file);

        // Subir a S3
        $s3 = new DBBS3_S3_Client(
            $config['access_key'],
            $config['secret_key'],
            $config['endpoint'],
            $config['region'],
            $config['bucket']
        );

        $upload_result = $s3->upload_file($zip_file, $s3_key, 'application/zip');

        if (is_wp_error($upload_result)) {
            $this->update_log($log_id, 'failed', $upload_result->get_error_message());
            return false;
        }

        // Éxito
        $file_size = filesize($zip_file);
        $this->update_log($log_id, 'success', '', $file_size, $upload_result['url']);

        // Limpiar archivo ZIP local (opcional, configurable)
        $keep_local = get_option('dbbs3_keep_local', 'no');
        if ($keep_local !== 'yes') {
            @unlink($zip_file);
        }

        // Limpiar backups antiguos
        $this->cleanup_old_backups($s3, $config);

        return true;
    }

    /**
     * Crea un dump de la base de datos MySQL
     */
    private function create_mysql_dump($output_file) {
        global $wpdb;

        // Intentar usar mysqldump primero
        $mysqldump_path = $this->find_mysqldump();
        if ($mysqldump_path) {
            $command = sprintf(
                '%s --host=%s --user=%s --password=%s --single-transaction --quick %s > %s 2>&1',
                escapeshellarg($mysqldump_path),
                escapeshellarg(DB_HOST),
                escapeshellarg(DB_USER),
                escapeshellarg(DB_PASSWORD),
                escapeshellarg(DB_NAME),
                escapeshellarg($output_file)
            );

            exec($command, $output, $return_code);

            if ($return_code === 0 && file_exists($output_file) && filesize($output_file) > 0) {
                return true;
            }
        }

        // Fallback: Crear dump con PHP puro
        return $this->create_php_dump($output_file);
    }

    /**
     * Busca la ruta de mysqldump
     */
    private function find_mysqldump() {
        $paths = array('mysqldump', '/usr/bin/mysqldump', '/usr/local/bin/mysqldump', '/usr/local/mysql/bin/mysqldump');
        foreach ($paths as $path) {
            $result = shell_exec('which ' . escapeshellarg($path) . ' 2>/dev/null');
            if ($result && file_exists(trim($result))) {
                return trim($result);
            }
        }
        // Probar directamente
        @exec('which mysqldump 2>/dev/null', $out, $code);
        if ($code === 0 && !empty($out[0])) {
            return $out[0];
        }
        return false;
    }

    /**
     * Crea un dump SQL usando PHP puro (fallback)
     */
    private function create_php_dump($output_file) {
        global $wpdb;

        $handle = fopen($output_file, 'w');
        if (!$handle) {
            return new WP_Error('write_error', 'No se pudo crear el archivo de backup.');
        }

        $db_name = DB_NAME;
        $timestamp = date('Y-m-d H:i:s');

        // Header
        fwrite($handle, "-- ---------------------------------------------\n");
        fwrite($handle, "-- DB Backup S3 - Export generado el {$timestamp}\n");
        fwrite($handle, "-- Base de datos: {$db_name}\n");
        fwrite($handle, "-- ---------------------------------------------\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($handle, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");
        fwrite($handle, "SET AUTOCOMMIT=0;\n");
        fwrite($handle, "START TRANSACTION;\n\n");

        // Obtener todas las tablas
        $tables = $wpdb->get_col("SHOW TABLES");
        if (empty($tables)) {
            fclose($handle);
            return new WP_Error('no_tables', 'No se encontraron tablas en la base de datos.');
        }

        foreach ($tables as $table) {
            // Estructura de la tabla
            fwrite($handle, "-- ---------------------------------------------\n");
            fwrite($handle, "-- Estructura de tabla: {$table}\n");
            fwrite($handle, "-- ---------------------------------------------\n");
            fwrite($handle, "DROP TABLE IF EXISTS `{$table}`;\n");

            $create_table = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_N);
            if ($create_table) {
                fwrite($handle, $create_table[1] . ";\n\n");
            }

            // Datos de la tabla
            $rows = $wpdb->get_results("SELECT * FROM `{$table}`", ARRAY_A);
            if (!empty($rows)) {
                fwrite($handle, "-- Datos de tabla: {$table}\n");

                $columns = array_keys($rows[0]);
                $column_list = '`' . implode('`, `', $columns) . '`';

                // Insertar en bloques de 100 filas
                $batch_size = 100;
                $total_rows = count($rows);

                for ($i = 0; $i < $total_rows; $i += $batch_size) {
                    $batch = array_slice($rows, $i, $batch_size);
                    fwrite($handle, "INSERT INTO `{$table}` ({$column_list}) VALUES\n");

                    $values_list = array();
                    foreach ($batch as $row) {
                        $values = array();
                        foreach ($row as $value) {
                            if ($value === null) {
                                $values[] = 'NULL';
                            } else {
                                $values[] = "'" . $wpdb->_real_escape($value) . "'";
                            }
                        }
                        $values_list[] = '(' . implode(', ', $values) . ')';
                    }

                    fwrite($handle, implode(",\n", $values_list));
                    fwrite($handle, ";\n");
                }
                fwrite($handle, "\n");
            }
        }

        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fwrite($handle, "COMMIT;\n");
        fclose($handle);

        return true;
    }

    /**
     * Comprime un archivo a ZIP
     */
    private function compress_file($source_file, $zip_file) {
        if (!class_exists('ZipArchive')) {
            // Si no hay ZipArchive, copiar sin comprimir
            if (copy($source_file, $zip_file)) {
                return true;
            }
            return new WP_Error('zip_error', 'La extension ZipArchive no esta disponible y no se pudo copiar el archivo.');
        }

        $zip = new ZipArchive();
        $result = $zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        if ($result !== true) {
            return new WP_Error('zip_error', 'No se pudo crear el archivo ZIP. Codigo: ' . $result);
        }

        $zip->addFile($source_file, basename($source_file));
        $zip->close();

        return true;
    }

    /**
     * Limpia backups antiguos según retención configurada
     */
    private function cleanup_old_backups($s3, $config) {
        $retention = (int) get_option('dbbs3_retention_days', 30);
        if ($retention <= 0) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$retention} days"));

        $old_backups = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE created_at < %s AND status = 'success' ORDER BY created_at ASC",
            $cutoff_date
        ));

        foreach ($old_backups as $backup) {
            if (!empty($backup->s3_key)) {
                $s3->delete_object($backup->s3_key);
            }
            $wpdb->delete($table_name, array('id' => $backup->id));
        }
    }

    /**
     * Registra un nuevo backup en la base de datos
     */
    private function log_backup($s3_key, $file_path, $status = 'pending') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';

        $wpdb->insert($table_name, array(
            'file_name'  => basename($file_path),
            'file_path'  => $file_path,
            's3_key'     => $s3_key,
            'status'     => $status,
            'created_at' => current_time('mysql'),
        ));

        return $wpdb->insert_id;
    }

    /**
     * Actualiza el estado de un backup
     */
    private function update_log($id, $status, $error = '', $file_size = 0, $s3_url = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'db_backup_s3_logs';

        $data = array(
            'status'       => $status,
            'completed_at' => current_time('mysql'),
        );

        if (!empty($error)) {
            $data['error_message'] = $error;
        }
        if ($file_size > 0) {
            $data['file_size'] = $file_size;
        }
        if (!empty($s3_url)) {
            $data['s3_url'] = $s3_url;
        }

        $wpdb->update($table_name, $data, array('id' => $id));
    }

    /**
     * Obtiene la configuración del plugin
     */
    public function get_config() {
        return array(
            'provider'   => get_option('dbbs3_provider', 'contabo'),
            'endpoint'   => get_option('dbbs3_endpoint', ''),
            'access_key' => get_option('dbbs3_access_key', ''),
            'secret_key' => get_option('dbbs3_secret_key', ''),
            'region'     => get_option('dbbs3_region', 'eu2'),
            'bucket'     => get_option('dbbs3_bucket', ''),
        );
    }

    /**
     * Verifica si la configuración está completa
     */
    public function is_configured($config = null) {
        if (null === $config) {
            $config = $this->get_config();
        }
        return !empty($config['endpoint'])
            && !empty($config['access_key'])
            && !empty($config['secret_key'])
            && !empty($config['bucket']);
    }
}
