<?php
/**
 * Cliente S3 Ligero con AWS Signature V4
 * No requiere el SDK de AWS. Compatible con Contabo, AWS, DigitalOcean Spaces, etc.
 */
class DBBS3_S3_Client {

    private $access_key;
    private $secret_key;
    private $endpoint;
    private $region;
    private $bucket;

    public function __construct($access_key, $secret_key, $endpoint, $region, $bucket) {
        $this->access_key = $access_key;
        $this->secret_key = $secret_key;
        $this->endpoint   = rtrim($endpoint, '/');
        $this->region     = $region;
        $this->bucket     = $bucket;
    }

    /**
     * Prueba la conexión listando los buckets
     */
    public function test_connection() {
        $response = $this->request('GET', '/', '', array(), '');
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }

    /**
     * Sube un archivo al bucket
     */
    public function upload_file($local_path, $s3_key, $content_type = 'application/octet-stream') {
        if (!file_exists($local_path)) {
            return new WP_Error('file_not_found', 'El archivo local no existe: ' . $local_path);
        }

        $body = file_get_contents($local_path);
        $headers = array(
            'Content-Type' => $content_type,
        );

        $response = $this->request('PUT', '/' . $s3_key, $body, $headers, $content_type);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array(
                'success' => true,
                'key'     => $s3_key,
                'url'     => $this->get_object_url($s3_key),
            );
        }

        return new WP_Error('upload_failed', 'Error al subir archivo. Código HTTP: ' . $code . ' - ' . wp_remote_retrieve_body($response));
    }

    /**
     * Obtiene la URL de un objeto
     */
    public function get_object_url($s3_key) {
        return $this->endpoint . '/' . $this->bucket . '/' . $s3_key;
    }

    /**
     * Obtiene URL prefirmada para descarga (válida 1 hora)
     */
    public function get_presigned_url($s3_key, $expires = 3600) {
        $method = 'GET';
        $uri = '/' . $this->bucket . '/' . $s3_key;
        $service = 's3';
        $time = time();
        $date_gmt = gmdate('Ymd\THis\Z', $time);
        $date_stamp = gmdate('Ymd', $time);

        $headers = array(
            'host' => parse_url($this->endpoint, PHP_URL_HOST),
        );
        $signed_headers = implode(';', array_keys($headers));
        $canonical_headers = '';
        foreach ($headers as $k => $v) {
            $canonical_headers .= $k . ':' . $v . "\n";
        }

        $credential = $this->access_key . '/' . $date_stamp . '/' . $this->region . '/' . $service . '/aws4_request';

        $params = array(
            'X-Amz-Algorithm'     => 'AWS4-HMAC-SHA256',
            'X-Amz-Credential'    => $credential,
            'X-Amz-Date'          => $date_gmt,
            'X-Amz-Expires'       => $expires,
            'X-Amz-SignedHeaders' => $signed_headers,
        );

        ksort($params);
        $query_string = http_build_query($params, '', '&', PHP_QUERY_RFC3986);

        $canonical_request = $method . "\n"
            . $uri . "\n"
            . $query_string . "\n"
            . $canonical_headers . "\n"
            . $signed_headers . "\n"
            . 'UNSIGNED-PAYLOAD';

        $string_to_sign = "AWS4-HMAC-SHA256\n"
            . $date_gmt . "\n"
            . $date_stamp . '/' . $this->region . '/' . $service . '/aws4_request\n'
            . hash('sha256', $canonical_request);

        $k_date    = hash_hmac('sha256', $date_stamp, 'AWS4' . $this->secret_key, true);
        $k_region  = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', $service, $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);

        $params['X-Amz-Signature'] = $signature;
        ksort($params);
        $final_query = http_build_query($params, '', '&', PHP_QUERY_RFC3986);

        return $this->endpoint . $uri . '?' . $final_query;
    }

    /**
     * Elimina un objeto del bucket
     */
    public function delete_object($s3_key) {
        $response = $this->request('DELETE', '/' . $s3_key, '', array(), '');
        if (is_wp_error($response)) {
            return $response;
        }
        $code = wp_remote_retrieve_response_code($response);
        return $code === 204 || $code === 200;
    }

    /**
     * Ejecuta una petición HTTP firmada con AWS Signature V4
     */
    private function request($method, $path, $body = '', $extra_headers = array(), $content_type = '') {
        $host = parse_url($this->endpoint, PHP_URL_HOST);
        $scheme = parse_url($this->endpoint, PHP_URL_SCHEME);

        $uri = '/' . $this->bucket . $path;
        $service = 's3';
        $time = time();
        $date_gmt = gmdate('Ymd\THis\Z', $time);
        $date_stamp = gmdate('Ymd', $time);

        $headers = array(
            'host' => $host,
            'x-amz-date' => $date_gmt,
            'x-amz-content-sha256' => hash('sha256', $body),
        );

        if (!empty($content_type)) {
            $headers['content-type'] = $content_type;
        }

        $headers = array_merge($headers, $extra_headers);
        ksort($headers);

        $signed_headers = implode(';', array_keys($headers));
        $canonical_headers = '';
        foreach ($headers as $k => $v) {
            $canonical_headers .= $k . ':' . $v . "\n";
        }

        $credential = $this->access_key . '/' . $date_stamp . '/' . $this->region . '/' . $service . '/aws4_request';

        $canonical_request = $method . "\n"
            . $uri . "\n"
            . "\n"
            . $canonical_headers . "\n"
            . $signed_headers . "\n"
            . hash('sha256', $body);

        $string_to_sign = "AWS4-HMAC-SHA256\n"
            . $date_gmt . "\n"
            . $date_stamp . '/' . $this->region . '/' . $service . '/aws4_request\n'
            . hash('sha256', $canonical_request);

        $k_date    = hash_hmac('sha256', $date_stamp, 'AWS4' . $this->secret_key, true);
        $k_region  = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', $service, $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);

        $authorization = 'AWS4-HMAC-SHA256 Credential=' . $credential
            . ', SignedHeaders=' . $signed_headers
            . ', Signature=' . $signature;

        $request_headers = array();
        foreach ($headers as $k => $v) {
            $request_headers[$k] = $v;
        }
        $request_headers['Authorization'] = $authorization;

        $url = $scheme . '://' . $host . $uri;
        $args = array(
            'method'    => $method,
            'headers'   => $request_headers,
            'body'      => $body,
            'timeout'   => 120,
            'sslverify' => true,
        );

        return wp_remote_request($url, $args);
    }
}
