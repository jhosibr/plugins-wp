/**
 * DB Backup S3 - Scripts del Panel Admin
 */
(function($) {
    'use strict';

    $(document).ready(function() {

        // Botón "Ejecutar Backup Ahora" en Dashboard
        $('#dbbs3-run-backup-now').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $result = $('#dbbs3-backup-result');

            if ($btn.prop('disabled')) return;

            $btn.prop('disabled', true).html('<span class="dbbs3-spinner"></span> Creando backup...');
            $result.empty();

            $.ajax({
                url: dbbs3_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dbbs3_run_backup_now',
                    nonce: dbbs3_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $result.html('<div class="dbbs3-result dbbs3-result-success">' +
                            '<span class="dashicons dashicons-yes-alt"></span> ' +
                            response.data + '</div>');
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    } else {
                        $result.html('<div class="dbbs3-result dbbs3-result-error">' +
                            '<span class="dashicons dashicons-warning"></span> ' +
                            response.data + '</div>');
                    }
                },
                error: function() {
                    $result.html('<div class="dbbs3-result dbbs3-result-error">' +
                        '<span class="dashicons dashicons-warning"></span> ' +
                        'Error de conexión. Intenta de nuevo.</div>');
                },
                complete: function() {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-cloud-upload"></span> Ejecutar Backup Ahora');
                }
            });
        });

        // Botón "Probar Conexión" en Dashboard
        $('#dbbs3-test-connection').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $result = $('#dbbs3-connection-result');

            $btn.prop('disabled', true).html('<span class="dbbs3-spinner"></span> Probando...');
            $result.empty();

            $.ajax({
                url: dbbs3_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dbbs3_test_connection',
                    nonce: dbbs3_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $result.html('<div class="dbbs3-result dbbs3-result-success">' +
                            '<span class="dashicons dashicons-yes-alt"></span> ' +
                            response.data + '</div>');
                    } else {
                        $result.html('<div class="dbbs3-result dbbs3-result-error">' +
                            '<span class="dashicons dashicons-warning"></span> ' +
                            response.data + '</div>');
                    }
                },
                error: function() {
                    $result.html('<div class="dbbs3-result dbbs3-result-error">' +
                        '<span class="dashicons dashicons-warning"></span> ' +
                        'Error de conexión.</div>');
                },
                complete: function() {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-site-alt3"></span> Probar Conexión');
                }
            });
        });

        // Botón "Probar Conexión S3" en página de configuración
        $('#dbbs3-test-connection-config').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $result = $('#dbbs3-config-test-result');

            // Guardar primero los valores actuales del formulario
            var formData = $('.dbbs3-form form').serialize();
            formData += '&action=dbbs3_test_connection&nonce=' + dbbs3_ajax.nonce;

            $btn.prop('disabled', true).html('<span class="dbbs3-spinner"></span> Probando conexión...');
            $result.empty();

            $.ajax({
                url: dbbs3_ajax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        $result.html('<span class="dbbs3-result dbbs3-result-success" style="display:inline;padding:8px 12px;">' +
                            '<span class="dashicons dashicons-yes-alt"></span> ' +
                            response.data + '</span>');
                    } else {
                        $result.html('<span class="dbbs3-result dbbs3-result-error" style="display:inline;padding:8px 12px;">' +
                            '<span class="dashicons dashicons-warning"></span> ' +
                            response.data + '</span>');
                    }
                },
                error: function() {
                    $result.html('<span class="dbbs3-result dbbs3-result-error" style="display:inline;padding:8px 12px;">' +
                        '<span class="dashicons dashicons-warning"></span> ' +
                        'Error de conexión al servidor.</span>');
                },
                complete: function() {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-site-alt3"></span> Probar Conexión S3');
                }
            });
        });

        // Botón "Eliminar Backup" en historial
        $(document).on('click', '.dbbs3-delete-btn', function(e) {
            e.preventDefault();
            if (!confirm('¿Estás seguro de que deseas eliminar este backup? Esta acción no se puede deshacer.')) {
                return;
            }

            var $btn = $(this);
            var $row = $btn.closest('tr');
            var id = $row.data('id');

            $btn.prop('disabled', true).html('<span class="dbbs3-spinner"></span>');

            $.ajax({
                url: dbbs3_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dbbs3_delete_backup',
                    nonce: dbbs3_ajax.nonce,
                    id: id
                },
                success: function(response) {
                    if (response.success) {
                        $row.fadeOut(300, function() {
                            $row.remove();
                            // Si no quedan filas, recargar
                            if ($('.dbbs3-table tbody tr').length === 0) {
                                window.location.reload();
                            }
                        });
                    } else {
                        alert(response.data);
                        $btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span>');
                    }
                },
                error: function() {
                    alert('Error al eliminar el backup.');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-trash"></span>');
                }
            });
        });

        // Botón "Descargar" backup desde S3
        $(document).on('click', '.dbbs3-download-btn', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var id = $btn.data('id');
            var key = $btn.data('key');

            $btn.prop('disabled', true).html('<span class="dbbs3-spinner"></span> Generando URL...');

            $.ajax({
                url: dbbs3_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dbbs3_download_backup',
                    nonce: dbbs3_ajax.nonce,
                    id: id,
                    key: key
                },
                success: function(response) {
                    if (response.success && response.data.url) {
                        window.open(response.data.url, '_blank');
                    } else {
                        alert('No se pudo generar el enlace de descarga.');
                    }
                },
                error: function() {
                    alert('Error de conexión.');
                },
                complete: function() {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-download"></span> Descargar');
                }
            });
        });

    });
})(jQuery);
