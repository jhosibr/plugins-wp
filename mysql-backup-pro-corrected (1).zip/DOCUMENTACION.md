# Documentación de Instalación y Configuración: MySQL Backup Pro

Este documento detalla los pasos necesarios para instalar, configurar y solucionar problemas del plugin **MySQL Backup Pro** para WordPress. El plugin permite realizar copias de seguridad automáticas de su base de datos MySQL y subirlas a un bucket S3, incluyendo compatibilidad específica con Contabo S3 y PHP 8.4+.

## 1. Requisitos del Sistema

Antes de instalar el plugin, asegúrese de que su entorno de WordPress cumpla con los siguientes requisitos:

*   **WordPress:** Versión 5.8 o superior.
*   **PHP:** Versión 8.4 o superior.
*   **Extensiones PHP:** `mysqli`, `openssl`, `zlib` (para compresión).
*   **Acceso de escritura:** El servidor web debe tener permisos de escritura en el directorio `wp-content/mysql-backup-pro/` para almacenar los backups temporalmente y los logs.
*   **Composer:** Necesario para instalar las dependencias del SDK de AWS.

## 2. Instalación del Plugin

Siga estos pasos para instalar el plugin:

1.  **Descargar el plugin:** Obtenga el archivo `mysql-backup-pro.zip`.
2.  **Descomprimir:** Descomprima el archivo `mysql-backup-pro.zip` en su máquina local.
3.  **Instalar dependencias con Composer:**
    *   Navegue a la carpeta raíz del plugin descomprimido (donde se encuentra `composer.json`).
    *   Ejecute el siguiente comando en su terminal:
        ```bash
        composer install --no-dev
        ```
    *   Si no tiene Composer instalado, puede descargarlo desde [getcomposer.org](https://getcomposer.org/).
4.  **Subir el plugin:** Suba la carpeta completa del plugin (incluyendo la nueva carpeta `vendor` generada por Composer) al directorio `wp-content/plugins/` de su instalación de WordPress.
5.  **Activar el plugin:** Desde el panel de administración de WordPress, vaya a `Plugins` y active **MySQL Backup Pro**.

## 3. Configuración del Plugin

Una vez activado, configure el plugin para que funcione correctamente:

1.  **Acceder a la configuración:** En el panel de administración de WordPress, vaya a `MySQL Backup Pro` > `Configuración`.

2.  **Configuración General:**
    *   **Backups Automáticos:** Active o desactive los backups programados.
    *   **Frecuencia de Backups:** Seleccione la frecuencia deseada (diaria, semanal, etc.).
    *   **Hora del Backup:** Establezca la hora específica en que se ejecutarán los backups.
    *   **Tipo de Backup:** Elija entre `Completo` o `Personalizado`. Si selecciona `Personalizado`, podrá especificar tablas a excluir.
    *   **Tablas a Excluir:** (Solo si el tipo de backup es `Personalizado`) Ingrese los nombres de las tablas que desea excluir, separadas por comas. Puede usar nombres con o sin el prefijo de la base de datos (ej. `wp_options`, `options`).
    *   **Comprimir Backups:** Active esta opción para comprimir los archivos de backup con `gzip`, reduciendo su tamaño.
    *   **Retención de Backups:** Defina el número máximo de backups a mantener. Los backups más antiguos se eliminarán automáticamente.
    *   **Email de Notificación:** Ingrese la dirección de correo electrónico donde desea recibir notificaciones sobre el estado de los backups (éxito o fallo).

3.  **Configuración del Bucket S3 (Contabo S3 y otros compatibles):**
    *   **Proveedor S3:** Seleccione `Contabo S3` o `Otro (compatible S3)`.
    *   **Región:** Para Contabo, la región suele ser `eu2` o similar. Si usa otro proveedor, seleccione la región adecuada o deje el valor por defecto si no aplica. **Es importante que este campo no esté vacío, aunque para Contabo el valor real se define por el Endpoint.**
    *   **Nombre del Bucket:** Ingrese el nombre exacto de su bucket S3 (ej. `backup-gestlife`).
    *   **Access Key:** Ingrese su clave de acceso S3. Esta clave se encriptará antes de guardarse en la base de datos de WordPress. **Si el campo aparece pre-rellenado con asteriscos, solo ingrese un nuevo valor si desea cambiarlo.**
    *   **Secret Key:** Ingrese su clave secreta S3. Esta clave también se encriptará. **Si el campo aparece pre-rellenado con asteriscos, solo ingrese un nuevo valor si desea cambiarlo.**
    *   **Endpoint URL:** **MUY IMPORTANTE para Contabo y otros proveedores no-AWS.** Ingrese la URL completa del endpoint de su servicio S3. Para Contabo, esto será similar a `https://eu2.contabostorage.com`. **Asegúrese de NO incluir el nombre del bucket al final de la URL del endpoint.** El plugin ajustará automáticamente el estilo de ruta (`path-style`) y la versión de firma (`Signature V4`) para compatibilidad, lo cual es crucial para evitar errores como `AuthorizationHeaderMalformed`.
    *   **Path Style:** Esta opción se activará automáticamente para proveedores no-AWS como Contabo, ya que es un requisito común para ellos. No es necesario activarla manualmente.

4.  **Probar Conexión S3:** Después de ingresar la configuración de S3, haga clic en el botón `Probar Conexión S3` para verificar que el plugin puede comunicarse con su bucket. Si la conexión es exitosa, recibirá un mensaje de confirmación. En caso de error, revise los datos ingresados y los permisos de su bucket. Si recibe un error `AuthorizationHeaderMalformed`, verifique que el `Endpoint URL` no contenga el nombre del bucket y que las claves sean correctas.

5.  **Guardar Configuración:** Haga clic en `Guardar Configuración` para aplicar todos los cambios.

## 4. Gestión de Backups

Desde la sección `MySQL Backup Pro` > `Backups`, podrá ver una lista de todos los backups realizados, su estado, tamaño y fecha. Desde aquí, también podrá:

*   **Descargar:** Descargar un backup a su máquina local.
*   **Eliminar:** Eliminar un backup del servidor y del bucket S3.
*   **Restaurar:** Restaurar una copia de seguridad de la base de datos. **¡Advertencia!** Esto sobrescribirá los datos actuales de su base de datos. Utilice esta función con extrema precaución.

## 5. Solución de Problemas Comunes

*   **Errores al guardar la configuración:**
    *   Asegúrese de que los campos de `Access Key` y `Secret Key` no estén vacíos.
    *   Verifique que el servidor tenga permisos de escritura en la base de datos de WordPress para guardar las opciones.
    *   Si el problema persiste, revise los logs de errores de PHP de su servidor para obtener más detalles.
*   **No se envían correos de notificación:**
    *   Verifique que la dirección de `Email de Notificación` esté correctamente configurada en los ajustes del plugin.
    *   Asegúrese de que su instalación de WordPress pueda enviar correos electrónicos. Puede probarlo con un plugin como WP Mail SMTP.
    *   Revise la carpeta de spam o correo no deseado del destinatario.
    *   Consulte los logs de errores de PHP para ver si hay problemas relacionados con la función `wp_mail()`.
*   **Problemas con Contabo S3 (Error `AuthorizationHeaderMalformed`):**
    *   **Endpoint URL:** Confirme que la `Endpoint URL` sea correcta y **NO incluya el nombre del bucket**. Por ejemplo, si su bucket es `backup-gestlife` y el endpoint es `https://eu2.contabostorage.com/backup-gestlife`, debe ingresar solo `https://eu2.contabostorage.com`. El plugin ahora fuerza el uso de `path-style` y `Signature V4` para Contabo, lo cual debería resolver este error.
    *   **Access Key y Secret Key:** Verifique que las credenciales sean correctas y tengan los permisos adecuados para leer y escribir en el bucket. Asegúrese de que no haya caracteres extraños o espacios en blanco.
    *   **Bucket Name:** Asegúrese de que el nombre del bucket sea exacto.
    *   **Región:** Aunque Contabo no usa regiones de AWS en el sentido tradicional, el campo es requerido por el SDK. Puede dejar el valor por defecto o seleccionar uno cercano si es necesario, pero el `Endpoint URL` es el que define la conexión real.
    *   **Permisos:** Asegúrese de que las políticas de su bucket en Contabo permitan las operaciones `s3:PutObject`, `s3:GetObject`, `s3:DeleteObject`, `s3:ListBucket`.
*   **Compatibilidad con PHP 8.4+:**
    *   El plugin ha sido actualizado para ser compatible con PHP 8.4 y versiones posteriores. Si experimenta problemas, asegúrese de haber ejecutado `composer install --no-dev` después de descomprimir el plugin para obtener las dependencias actualizadas.
    *   Si ve errores relacionados con `strlen()` o `trim()` esperando un string, es probable que haya un valor `null` o no-string. Las correcciones implementadas manejan esto, pero si el problema persiste, verifique la integridad de su base de datos.

## 6. Soporte

Si encuentra algún problema que no pueda resolver con esta documentación, por favor, contacte al equipo de soporte del plugin, proporcionando la mayor cantidad de detalles posible, incluyendo mensajes de error, capturas de pantalla y los pasos para reproducir el problema.

---
