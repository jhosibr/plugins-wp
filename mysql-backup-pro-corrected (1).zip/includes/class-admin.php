<?php
/**
 * Clase para manejar el panel de administración
 */
class MBP_Admin
{
    private static $instance = null;

    private function __construct()
    {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'handle_post_requests']);
    }

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function add_admin_menu()
    {
        // Menú principal
        add_menu_page(
            __('MySQL Backup Pro', 'mysql-backup-pro'),
            __('MySQL Backup Pro', 'mysql-backup-pro'),
            'manage_options',
            'mysql-backup-pro',
            [$this, 'render_dashboard'],
            'dashicons-database',
            76
        );

        // Submenús
        add_submenu_page(
            'mysql-backup-pro',
            __('Dashboard', 'mysql-backup-pro'),
            __('Dashboard', 'mysql-backup-pro'),
            'manage_options',
            'mysql-backup-pro',
            [$this, 'render_dashboard']
        );

        add_submenu_page(
            'mysql-backup-pro',
            __('Backups', 'mysql-backup-pro'),
            __('Backups', 'mysql-backup-pro'),
            'manage_options',
            'mysql-backup-pro-backups',
            [$this, 'render_backups']
        );

        add_submenu_page(
            'mysql-backup-pro',
            __('Configuración', 'mysql-backup-pro'),
            __('Configuración', 'mysql-backup-pro'),
            'manage_options',
            'mysql-backup-pro-settings',
            [$this, 'render_settings']
        );

        add_submenu_page(
            'mysql-backup-pro',
            __('WP Users (Test)', 'mysql-backup-pro'),
            __('WP Users (Test)', 'mysql-backup-pro'),
            'manage_options',
            'mysql-backup-pro-users',
            [$this, 'render_users']
        );
    }

    public function render_dashboard()
    {
        include MBP_PLUGIN_DIR . 'admin/partials/dashboard.php';
    }

    public function render_backups()
    {
        include MBP_PLUGIN_DIR . 'admin/partials/backups.php';
    }

    public function render_settings()
    {
        include MBP_PLUGIN_DIR . 'admin/partials/settings.php';
    }

    public function render_users()
    {
        include MBP_PLUGIN_DIR . 'admin/partials/users.php';
    }

    public function handle_post_requests()
    {
        if (!isset($_POST['mbp_save_settings'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['mbp_settings_nonce'], 'mbp_save_settings')) {
            add_settings_error('mbp_messages', 'mbp_error', 'Error de seguridad', 'error');
            return;
        }

        $this->save_settings($_POST);
    }

    public function save_settings($data)
    {
        $fields = [
            'mbp_enabled',
            'mbp_backup_frequency',
            'mbp_backup_time',
            'mbp_backup_type',
            'mbp_s3_provider',
            'mbp_s3_region',
            'mbp_s3_bucket',
            'mbp_s3_access_key',
            'mbp_s3_secret_key',
            'mbp_s3_endpoint',
            'mbp_s3_path_style',
            'mbp_retention_count',
            'mbp_compress_backup',
            'mbp_exclude_tables',
            'mbp_notify_email',
        ];

        foreach ($fields as $field) {
            if (isset($data[$field])) {
                $value = sanitize_text_field($data[$field]);
                
                // Encriptar llaves de S3 antes de guardar
                if ($field === 'mbp_s3_access_key' || $field === 'mbp_s3_secret_key') {
                    // Solo encriptar si el valor ha cambiado (no es la versión enmascarada del frontend)
                    $current_value = $this->decrypt_value(get_option($field, ''));
                    if ($value !== $current_value && !empty($value)) {
                        $value = $this->encrypt_value($value);
                    } else {
                        // Mantener el valor actual si no cambió
                        continue;
                    }
                }
                
                update_option($field, $value);
            } else {
                // Manejar checkboxes que no se envían si están desmarcados
                if ($field === 'mbp_enabled' || $field === 'mbp_compress_backup' || $field === 'mbp_s3_path_style') {
                    update_option($field, '0');
                }
            }
        }

        // Reprogramar cron según la frecuencia
        $this->reschedule_backup($data['mbp_backup_frequency'] ?? 'daily', $data['mbp_backup_time'] ?? '02:00');

        return [
            'success' => true,
            'message' => 'Configuración guardada correctamente'
        ];
    }

    private function reschedule_backup($frequency, $time)
    {
        // Limpiar crons existentes
        wp_clear_scheduled_hook('mbp_daily_backup');
        wp_clear_scheduled_hook('mbp_weekly_backup');
        wp_clear_scheduled_hook('mbp_custom_backup');

        $time_parts = explode(':', $time);
        $hour = intval($time_parts[0]);
        $minute = intval($time_parts[1]);
        
        $timestamp = strtotime("today {$hour}:{$minute}:00");
        if ($timestamp < time()) {
            $timestamp = strtotime("tomorrow {$hour}:{$minute}:00");
        }

        switch ($frequency) {
            case 'hourly':
                wp_schedule_event($timestamp, 'hourly', 'mbp_daily_backup');
                break;
            case 'twicedaily':
                wp_schedule_event($timestamp, 'twicedaily', 'mbp_daily_backup');
                break;
            case 'daily':
                wp_schedule_event($timestamp, 'daily', 'mbp_daily_backup');
                break;
            case 'weekly':
                wp_schedule_event($timestamp, 'weekly', 'mbp_daily_backup');
                break;
            default:
                wp_schedule_event($timestamp, 'daily', 'mbp_daily_backup');
                break;
        }
    }

    public function get_settings()
    {
        return [
            'enabled' => get_option('mbp_enabled', '1'),
            'backup_frequency' => get_option('mbp_backup_frequency', 'daily'),
            'backup_time' => get_option('mbp_backup_time', '02:00'),
            'backup_type' => get_option('mbp_backup_type', 'full'),
            's3_provider' => get_option('mbp_s3_provider', 'aws'),
            's3_region' => get_option('mbp_s3_region', 'us-east-1'),
            's3_bucket' => get_option('mbp_s3_bucket', ''),
            's3_access_key' => $this->decrypt_value(get_option('mbp_s3_access_key', '')),
            's3_secret_key' => $this->decrypt_value(get_option('mbp_s3_secret_key', '')),
            's3_endpoint' => get_option('mbp_s3_endpoint', ''),
            's3_path_style' => get_option('mbp_s3_path_style', '0'),
            'retention_count' => get_option('mbp_retention_count', '10'),
            'compress_backup' => get_option('mbp_compress_backup', '1'),
            'exclude_tables' => get_option('mbp_exclude_tables', ''),
            'notify_email' => get_option('mbp_notify_email', get_option('admin_email')),
        ];
    }

    private function encrypt_value($value)
    {
        if (empty($value)) {
            return '';
        }
        $key = $this->get_encryption_key();
        $iv = $this->get_encryption_iv();
        $encrypted = openssl_encrypt($value, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($encrypted);
    }

    private function decrypt_value($value)
    {
        if (empty($value)) {
            return '';
        }
        
        $decoded = base64_decode($value, true);
        if ($decoded === false) {
            return $value;
        }

        $decrypted = @openssl_decrypt($decoded, 'AES-256-CBC', $this->get_encryption_key(), 0, $this->get_encryption_iv());
        return $decrypted !== false ? $decrypted : $value;
    }

    private function get_encryption_key()
    {
        $key = get_option('mbp_encryption_key');
        if (!$key) {
            $key = wp_generate_password(32, true, true);
            update_option('mbp_encryption_key', $key);
        }
        return $key;
    }

    private function get_encryption_iv()
    {
        $iv = get_option('mbp_encryption_iv');
        if (!$iv) {
            $iv = wp_generate_password(16, true, true);
            update_option('mbp_encryption_iv', $iv);
        }
        return $iv;
    }

    public function get_stats()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mbp_backups';

        $total_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        $successful_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'completed'");
        $failed_backups = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE status = 'failed'");
        $last_backup = $wpdb->get_row("SELECT * FROM {$table_name} WHERE status = 'completed' ORDER BY completed_at DESC LIMIT 1");
        $total_size = $wpdb->get_var("SELECT COALESCE(SUM(file_size), 0) FROM {$table_name} WHERE status = 'completed'");

        // Obtener información de la base de datos
        $db_name = DB_NAME;
        $db_size = $wpdb->get_var("SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = '{$db_name}'");
        $table_count = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '{$db_name}' AND table_type = 'BASE TABLE'");

        return [
            'total_backups' => intval($total_backups),
            'successful_backups' => intval($successful_backups),
            'failed_backups' => intval($failed_backups),
            'last_backup' => $last_backup,
            'total_size' => $this->format_bytes(intval($total_size)),
            'db_name' => $db_name,
            'db_size' => $this->format_bytes(intval($db_size)),
            'table_count' => intval($table_count),
            'next_backup' => $this->get_next_backup_time(),
        ];
    }

    private function get_next_backup_time()
    {
        $timestamp = wp_next_scheduled('mbp_daily_backup');
        if ($timestamp) {
            return date_i18n('Y-m-d H:i:s', $timestamp);
        }
        return __('No programado', 'mysql-backup-pro');
    }

    public function format_bytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= (1 << (10 * $pow));
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}
