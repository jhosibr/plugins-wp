<?php
/**
 * Plugin Name: MySQL Backup Pro
 * Plugin URI: https://github.com/yourcompany/mysql-backup-pro
 * Description: Plugin profesional para respaldos automáticos de MySQL a S3 con panel de administración, configuración flexible y tablero de pruebas.
 * Version: 1.1.0
 * Author: MySQL Backup Pro Team
 * Author URI: https://github.com/yourcompany/mysql-backup-pro
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: mysql-backup-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 8.4
 */

// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes del plugin
define('MBP_VERSION', '1.1.0');
define('MBP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MBP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MBP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'MBP_';
    $base_dir = MBP_PLUGIN_DIR . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = strtolower(substr($class, $len));
    $relative_class = str_replace('_', '-', $relative_class);
    $file = $base_dir . 'class-' . $relative_class . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Cargar AWS SDK si está disponible
$autoload_file = MBP_PLUGIN_DIR . 'vendor/autoload.php';
if (file_exists($autoload_file)) {
    require_once $autoload_file;
}

/**
 * Clase principal del plugin
 */
class MySQL_Backup_Pro
{
    private static $instance = null;

    private function __construct()
    {
        // Hooks de activación y desactivación
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // Inicializar componentes
        add_action('plugins_loaded', [$this, 'init']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Ajax handlers
        add_action('wp_ajax_mbp_run_backup', [$this, 'ajax_run_backup']);
        add_action('wp_ajax_mbp_delete_backup', [$this, 'ajax_delete_backup']);
        add_action('wp_ajax_mbp_download_backup', [$this, 'ajax_download_backup']);
        add_action('wp_ajax_mbp_test_connection', [$this, 'ajax_test_connection']);
        add_action('wp_ajax_mbp_save_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_mbp_get_backups', [$this, 'ajax_get_backups']);
        add_action('wp_ajax_mbp_restore_backup', [$this, 'ajax_restore_backup']);
    }

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init()
    {
        // Inicializar administrador
        if (is_admin()) {
            MBP_Admin::get_instance();
        }

        // Inicializar scheduler
        MBP_Scheduler::get_instance();
    }

    public function activate()
    {
        MBP_Activator::activate();
    }

    public function deactivate()
    {
        MBP_Deactivator::deactivate();
    }

    public function enqueue_admin_assets($hook)
    {
        if (strpos($hook, 'mysql-backup-pro') === false) {
            return;
        }

        wp_enqueue_style(
            'mbp-admin-css',
            MBP_PLUGIN_URL . 'admin/css/admin-style.css',
            [],
            MBP_VERSION
        );

        wp_enqueue_script(
            'mbp-admin-js',
            MBP_PLUGIN_URL . 'admin/js/admin-script.js',
            ['jquery'],
            MBP_VERSION,
            true
        );

        wp_localize_script('mbp-admin-js', 'mbp_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mbp_nonce'),
            'strings' => [
                'confirmDelete' => __('¿Estás seguro de que deseas eliminar este backup?', 'mysql-backup-pro'),
                'confirmRestore' => __('¿Estás seguro de que deseas restaurar este backup? Se sobrescribirán los datos actuales.', 'mysql-backup-pro'),
                'backupStarted' => __('Respaldo iniciado...', 'mysql-backup-pro'),
                'backupSuccess' => __('¡Respaldo completado exitosamente!', 'mysql-backup-pro'),
                'backupError' => __('Error al realizar el respaldo', 'mysql-backup-pro'),
                'deleteSuccess' => __('Backup eliminado correctamente', 'mysql-backup-pro'),
                'settingsSaved' => __('Configuración guardada correctamente', 'mysql-backup-pro'),
                'connectionSuccess' => __('¡Conexión exitosa!', 'mysql-backup-pro'),
                'connectionError' => __('Error de conexión', 'mysql-backup-pro'),
            ]
        ]);
    }

    // AJAX Handlers
    public function ajax_run_backup()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $backup = new MBP_Backup();
        $result = $backup->run_backup();

        if ($result['success']) {
            // Enviar notificación también en backups manuales
            $scheduler = MBP_Scheduler::get_instance();
            $scheduler->send_notification($result, true);
            
            wp_send_json_success($result);
        } else {
            // Enviar notificación de error
            $scheduler = MBP_Scheduler::get_instance();
            $scheduler->send_notification(['message' => $result['message'] ?? 'Error desconocido'], false);
            
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_delete_backup()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $id = intval($_POST['id']);
        $backup = new MBP_Backup();
        $result = $backup->delete_backup($id);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_download_backup()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $id = intval($_POST['id']);
        $backup = new MBP_Backup();
        $result = $backup->get_download_url($id);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_test_connection()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $s3 = new MBP_S3_Handler();
        $result = $s3->test_connection();

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_save_settings()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $settings = new MBP_Admin();
        $result = $settings->save_settings($_POST);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_get_backups()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $backup = new MBP_Backup();
        $backups = $backup->get_all_backups();
        
        wp_send_json_success(['backups' => $backups]);
    }

    public function ajax_restore_backup()
    {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permisos insuficientes');
        }

        $id = intval($_POST['id']);
        $backup = new MBP_Backup();
        $result = $backup->restore_backup($id);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
}

// Inicializar plugin
MySQL_Backup_Pro::get_instance();
