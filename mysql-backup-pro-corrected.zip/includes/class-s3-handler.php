<?php
/**
 * Clase para manejar la conexión y operaciones con S3
 */
class MBP_S3_Handler
{
    private $client = null;
    private $configured = false;

    public function __construct()
    {
        $this->check_configuration();
    }

    /**
     * Verificar si la configuración de S3 está completa
     */
    private function check_configuration()
    {
        $bucket = get_option('mbp_s3_bucket', '');
        $access_key = get_option('mbp_s3_access_key', '');
        $secret_key = get_option('mbp_s3_secret_key', '');

        if (!empty($bucket) && !empty($access_key) && !empty($secret_key)) {
            $this->configured = true;
        }
    }

    /**
     * Verificar si S3 está configurado
     */
    public function is_configured()
    {
        return $this->configured;
    }

    /**
     * Obtener el cliente S3
     */
    private function get_client()
    {
        if ($this->client !== null) {
            return $this->client;
        }

        if (!class_exists('Aws\S3\S3Client')) {
            // Intentar cargar el SDK manualmente
            $sdk_path = MBP_PLUGIN_DIR . 'vendor/aws/aws-sdk-php/src/S3/S3Client.php';
            if (file_exists($sdk_path)) {
                require_once MBP_PLUGIN_DIR . 'vendor/autoload.php';
            } else {
                return null;
            }
        }

        if (!class_exists('Aws\S3\S3Client')) {
            return null;
        }

        $provider = get_option('mbp_s3_provider', 'aws');
        $region = get_option('mbp_s3_region', 'us-east-1');
        $access_key = $this->decrypt(get_option('mbp_s3_access_key', ''));
        $secret_key = $this->decrypt(get_option('mbp_s3_secret_key', ''));
        $endpoint = get_option('mbp_s3_endpoint', '');
        $path_style = get_option('mbp_s3_path_style', '0') === '1';

        $config = [
            'version' => 'latest',
            'region' => $region,
            'credentials' => [
                'key' => $access_key,
                'secret' => $secret_key,
            ],
        ];

        // Configuración para servicios no-AWS (Contabo, MinIO, Wasabi, etc.)
        if ($provider !== 'aws' && !empty($endpoint)) {
            // Asegurarse de que el endpoint no incluya el nombre del bucket al final
            $bucket_name = get_option('mbp_s3_bucket', '');
            if (!empty($bucket_name) && strpos($endpoint, '/' . $bucket_name) !== false) {
                $endpoint = str_replace('/' . $bucket_name, '', $endpoint);
            }
            
            $config['endpoint'] = $endpoint;
            $config['use_path_style_endpoint'] = true; // Contabo usualmente requiere path style
            
            $config['http'] = [
                'verify' => true,
            ];
        }

        try {
            $this->client = new Aws\S3\S3Client($config);
            return $this->client;
        } catch (Exception $e) {
            error_log('MySQL Backup Pro - Error S3: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Probar conexión con S3
     */
    public function test_connection()
    {
        try {
            $client = $this->get_client();
            
            if (!$client) {
                return [
                    'success' => false,
                    'message' => 'No se pudo inicializar el cliente S3. Verifique que el SDK de AWS esté instalado.'
                ];
            }

            $bucket = get_option('mbp_s3_bucket', '');
            
            // Intentar listar buckets
            $buckets = $client->listBuckets();
            
            // Verificar que el bucket existe
            $bucket_exists = false;
            foreach ($buckets['Buckets'] as $b) {
                if ($b['Name'] === $bucket) {
                    $bucket_exists = true;
                    break;
                }
            }

            if (!$bucket_exists) {
                return [
                    'success' => false,
                    'message' => "Conexión exitosa, pero el bucket '{$bucket}' no existe. Buckets disponibles: " . implode(', ', array_column($buckets['Buckets'], 'Name'))
                ];
            }

            // Intentar listar objetos del bucket
            $objects = $client->listObjectsV2([
                'Bucket' => $bucket,
                'MaxKeys' => 1,
            ]);

            return [
                'success' => true,
                'message' => "¡Conexión exitosa! Bucket '{$bucket}' accesible."
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Subir archivo a S3
     */
    public function upload_file($filepath, $key)
    {
        try {
            $client = $this->get_client();
            
            if (!$client) {
                return ['success' => false, 'message' => 'Cliente S3 no disponible'];
            }

            $bucket = get_option('mbp_s3_bucket', '');
            $prefix = 'mysql-backups/' . date('Y/m/');
            $full_key = $prefix . $key;

            $result = $client->putObject([
                'Bucket' => $bucket,
                'Key' => $full_key,
                'SourceFile' => $filepath,
                'ContentType' => 'application/octet-stream',
                'StorageClass' => 'STANDARD_IA', // Infrequent Access para reducir costos
            ]);

            return [
                'success' => true,
                'key' => $full_key,
                'bucket' => $bucket,
                'url' => $result['ObjectURL'] ?? '',
                'message' => 'Archivo subido correctamente'
            ];

        } catch (Exception $e) {
            error_log('MySQL Backup Pro - Error subiendo archivo: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Eliminar archivo de S3
     */
    public function delete_file($key)
    {
        try {
            $client = $this->get_client();
            
            if (!$client) {
                return ['success' => false, 'message' => 'Cliente S3 no disponible'];
            }

            $bucket = get_option('mbp_s3_bucket', '');
            
            $client->deleteObject([
                'Bucket' => $bucket,
                'Key' => $key,
            ]);

            return ['success' => true, 'message' => 'Archivo eliminado de S3'];

        } catch (Exception $e) {
            error_log('MySQL Backup Pro - Error eliminando archivo: ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Generar URL presignada para descarga
     */
    public function get_presigned_url($key, $expires = '+15 minutes')
    {
        try {
            $client = $this->get_client();
            
            if (!$client) {
                return ['success' => false, 'message' => 'Cliente S3 no disponible'];
            }

            $bucket = get_option('mbp_s3_bucket', '');
            
            $cmd = $client->getCommand('GetObject', [
                'Bucket' => $bucket,
                'Key' => $key,
            ]);

            $request = $client->createPresignedRequest($cmd, $expires);
            $url = (string) $request->getUri();

            return [
                'success' => true,
                'type' => 's3',
                'url' => $url,
                'filename' => basename($key)
            ];

        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Desencriptar valor
     */
        private function decrypt($value)
    {
        if (empty($value)) {
            return '';
        }

        $key = get_option('mbp_encryption_key');
        $iv = get_option('mbp_encryption_iv');

        if (!$key || !$iv) {
            return $value;
        }

        $decoded = base64_decode($value, true);
        if ($decoded === false) {
            return $value;
        }

        $decrypted = @openssl_decrypt($decoded, 'AES-256-CBC', $key, 0, $iv);
        return $decrypted !== false ? $decrypted : $value;
    }
}
