<?php
/**
 * Clase para manejar la programación de backups automáticos
 */
class MBP_Scheduler
{
    private static $instance = null;

    private function __construct()
    {
        // Registrar intervalos personalizados
        add_filter('cron_schedules', [$this, 'add_cron_intervals']);
        
        // Hook para el backup automático
        add_action('mbp_daily_backup', [$this, 'run_scheduled_backup']);
        add_action('mbp_weekly_backup', [$this, 'run_scheduled_backup']);
        add_action('mbp_custom_backup', [$this, 'run_scheduled_backup']);
    }

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Agregar intervalos personalizados de cron
     */
    public function add_cron_intervals($schedules)
    {
        // Cada 6 horas
        $schedules['every_6_hours'] = [
            'interval' => 21600,
            'display' => __('Cada 6 horas', 'mysql-backup-pro')
        ];

        // Cada 12 horas
        $schedules['every_12_hours'] = [
            'interval' => 43200,
            'display' => __('Cada 12 horas', 'mysql-backup-pro')
        ];

        // Cada 3 días
        $schedules['every_3_days'] = [
            'interval' => 259200,
            'display' => __('Cada 3 días', 'mysql-backup-pro')
        ];

        // Semanalmente
        $schedules['weekly'] = [
            'interval' => 604800,
            'display' => __('Semanalmente', 'mysql-backup-pro')
        ];

        // Quincenal
        $schedules['biweekly'] = [
            'interval' => 1209600,
            'display' => __('Cada 2 semanas', 'mysql-backup-pro')
        ];

        // Mensual
        $schedules['monthly'] = [
            'interval' => 2592000,
            'display' => __('Mensualmente', 'mysql-backup-pro')
        ];

        return $schedules;
    }

    /**
     * Ejecutar backup programado
     */
    public function run_scheduled_backup()
    {
        // Verificar que los backups están habilitados
        if (get_option('mbp_enabled', '1') !== '1') {
            return;
        }

        // Verificar que no haya un backup en ejecución
        $lock_key = 'mbp_backup_lock';
        if (get_transient($lock_key)) {
            error_log('MySQL Backup Pro - Ya hay un backup en ejecución');
            return;
        }

        // Establecer lock para evitar ejecuciones simultáneas
        set_transient($lock_key, true, HOUR_IN_SECONDS);

        try {
            $backup = new MBP_Backup();
            $result = $backup->run_backup('automatic');

            if ($result['success']) {
                $this->log_message("Backup automático completado: {$result['filename']} ({$result['file_size']})");
                $this->send_notification($result, true);
            } else {
                $this->log_message("Backup automático fallido: {$result['message']}", 'error');
                $this->send_notification($result, false);
            }
        } catch (Exception $e) {
            $this->log_message("Error en backup automático: {$e->getMessage()}", 'error');
        } finally {
            // Liberar lock
            delete_transient($lock_key);
        }
    }

    /**
     * Enviar notificación por email
     */
    public function send_notification($result, $success)
    {
        $email = get_option('mbp_notify_email', get_option('admin_email'));
        
        if (empty($email)) {
            return;
        }

        $site_name = get_bloginfo('name');
        
        if ($success) {
            $subject = "[{$site_name}] Backup Completado - MySQL Backup Pro";
            $message = "El respaldo de la base de datos se ha completado exitosamente.\n\n";
            $message .= "Detalles:\n";
            $message .= "- Archivo: {$result['filename']}\n";
            $message .= "- Tamaño: {$result['file_size']}\n";
            $message .= "- Tablas: {$result['tables']}\n";
            $message .= "- Filas: {$result['rows']}\n";
            $message .= "- Duración: {$result['duration']} segundos\n";
            $message .= "- S3: " . ($result['s3_uploaded'] ? 'Subido correctamente' : 'No configurado') . "\n";
            $message .= "\nFecha: " . date('Y-m-d H:i:s') . "\n";
        } else {
            $subject = "[{$site_name}] Backup Fallido - MySQL Backup Pro";
            $message = "El respaldo de la base de datos ha fallado.\n\n";
            $message .= "Error: {$result['message']}\n";
            $message .= "\nFecha: " . date('Y-m-d H:i:s') . "\n";
            $message .= "\nPor favor, verifique la configuración del plugin.\n";
        }

        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        wp_mail($email, $subject, $message, $headers);
    }

    /**
     * Registrar mensaje en el log
     */
    private function log_message($message, $level = 'info')
    {
        $log_file = WP_CONTENT_DIR . '/mysql-backup-pro/backup.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        error_log("MySQL Backup Pro - {$message}");
        
        if (is_writable(dirname($log_file))) {
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        }
    }
}
