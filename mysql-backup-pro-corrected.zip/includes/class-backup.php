<?php
/**
 * Clase para manejar los respaldos de la base de datos
 */
class MBP_Backup
{
    private $backup_dir;
    private $wpdb;
    private $s3_handler;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->backup_dir = WP_CONTENT_DIR . '/mysql-backup-pro/';
        $this->s3_handler = new MBP_S3_Handler();
    }

    /**
     * Ejecutar un respaldo completo
     */
    public function run_backup($type = 'manual')
    {
        try {
            ini_set('max_execution_time', 300);
            ini_set('memory_limit', '512M');

            $start_time = microtime(true);
            $timestamp = date('Y-m-d_H-i-s');
            $db_name = DB_NAME;
            $filename = "backup_{$db_name}_{$timestamp}.sql";
            $filepath = $this->backup_dir . $filename;

            // Crear registro en la base de datos
            $backup_id = $this->create_backup_record($filename, $filepath, $type);
            
            if (!$backup_id) {
                throw new Exception('Error al crear el registro del backup');
            }

            // Generar el archivo SQL
            $result = $this->generate_sql_dump($filepath, $backup_id);
            
            if (!$result['success']) {
                throw new Exception($result['message']);
            }

            $file_size = filesize($filepath);
            $compressed_path = $filepath;

            // Comprimir si está habilitado
            if (get_option('mbp_compress_backup', '1') === '1') {
                $compressed_path = $this->compress_file($filepath);
                if ($compressed_path !== $filepath) {
                    $file_size = filesize($compressed_path);
                    // Eliminar archivo original si se comprimió
                    if (file_exists($filepath) && $filepath !== $compressed_path) {
                        @unlink($filepath);
                    }
                }
            }

            // Subir a S3 si está configurado
            $s3_result = ['success' => false, 'url' => ''];
            if ($this->s3_handler->is_configured()) {
                $s3_result = $this->s3_handler->upload_file($compressed_path, basename($compressed_path));
            }

            // Actualizar registro
            $this->update_backup_record($backup_id, [
                'file_size' => $file_size,
                'file_path' => $compressed_path,
                'tables_backed_up' => $result['tables'],
                'rows_count' => $result['rows'],
                'status' => 'completed',
                'completed_at' => current_time('mysql'),
                's3_key' => $s3_result['key'] ?? null,
                's3_bucket' => $s3_result['bucket'] ?? null,
                's3_region' => get_option('mbp_s3_region'),
            ]);

            // Limpiar backups antiguos
            $this->cleanup_old_backups();

            $duration = round(microtime(true) - $start_time, 2);

            return [
                'success' => true,
                'backup_id' => $backup_id,
                'filename' => basename($compressed_path),
                'file_size' => $this->format_bytes($file_size),
                'tables' => $result['tables'],
                'rows' => $result['rows'],
                's3_uploaded' => $s3_result['success'],
                's3_url' => $s3_result['url'] ?? '',
                'duration' => $duration,
                'message' => sprintf('Backup completado en %s segundos', $duration)
            ];

        } catch (Exception $e) {
            if (isset($backup_id)) {
                $this->update_backup_record($backup_id, [
                    'status' => 'failed',
                    'error_message' => $e->getMessage(),
                    'completed_at' => current_time('mysql'),
                ]);
            }

            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Generar el dump SQL usando PHP puro (compatible con todos los hosts)
     */
    private function generate_sql_dump($filepath, $backup_id)
    {
        $handle = fopen($filepath, 'w');
        if (!$handle) {
            return ['success' => false, 'message' => 'No se pudo crear el archivo de backup'];
        }

        $db_name = DB_NAME;
        $tables_backed = [];
        $total_rows = 0;
        $exclude_tables = $this->get_excluded_tables();

        // Header del archivo SQL
        fwrite($handle, "-- MySQL Backup Pro - Database Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Base de datos: {$db_name}\n");
        fwrite($handle, "-- Plugin: MySQL Backup Pro v" . MBP_VERSION . "\n");
        fwrite($handle, "-- \n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($handle, "SET SQL_MODE=\"NO_AUTO_VALUE_ON_ZERO\";\n");
        fwrite($handle, "SET AUTOCOMMIT=0;\n");
        fwrite($handle, "START TRANSACTION;\n\n");

        // Obtener lista de tablas
        $tables = $this->wpdb->get_results("SHOW TABLES", ARRAY_N);
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            
            // Saltar tablas excluidas
            if (in_array($table_name, $exclude_tables)) {
                continue;
            }

            $tables_backed[] = $table_name;

            // Estructura de la tabla
            fwrite($handle, "-- \n");
            fwrite($handle, "-- Estructura de la tabla `{$table_name}`\n");
            fwrite($handle, "-- \n\n");
            
            // DROP TABLE IF EXISTS
            fwrite($handle, "DROP TABLE IF EXISTS `{$table_name}`;\n");

            // CREATE TABLE
            $create_table = $this->wpdb->get_row("SHOW CREATE TABLE `{$table_name}`", ARRAY_N);
            if ($create_table) {
                fwrite($handle, $create_table[1] . ";\n\n");
            }

            // Datos de la tabla
            $row_count = $this->wpdb->get_var("SELECT COUNT(*) FROM `{$table_name}`");
            
            if ($row_count > 0) {
                fwrite($handle, "-- \n");
                fwrite($handle, "-- Datos de la tabla `{$table_name}`\n");
                fwrite($handle, "-- \n\n");

                // Obtener columnas
                $columns = $this->wpdb->get_results("SHOW COLUMNS FROM `{$table_name}`", ARRAY_A);
                $column_names = array_map(function($col) {
                    return '`' . $col['Field'] . '`';
                }, $columns);

                // Procesar en lotes para tablas grandes
                $batch_size = 1000;
                $offset = 0;

                while ($offset < $row_count) {
                    $rows = $this->wpdb->get_results(
                        $this->wpdb->prepare(
                            "SELECT * FROM `{$table_name}` LIMIT %d OFFSET %d",
                            $batch_size,
                            $offset
                        ),
                        ARRAY_A
                    );

                    if (empty($rows)) {
                        break;
                    }

                    // Generar INSERTs
                    $values_batch = [];
                    foreach ($rows as $row) {
                        $values = [];
                        foreach ($row as $value) {
                            if ($value === null) {
                                $values[] = 'NULL';
                            } else {
                                $values[] = "'" . $this->wpdb->_real_escape($value) . "'";
                            }
                        }
                        $values_batch[] = '(' . implode(', ', $values) . ')';
                        $total_rows++;
                    }

                    if (!empty($values_batch)) {
                        fwrite($handle, "INSERT INTO `{$table_name}` (" . implode(', ', $column_names) . ") VALUES\n");
                        fwrite($handle, implode(",\n", $values_batch) . ";\n");
                    }

                    $offset += $batch_size;
                }

                fwrite($handle, "\n");
            }
        }

        // Footer del archivo SQL
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fwrite($handle, "COMMIT;\n");
        fwrite($handle, "-- Fin del backup\n");

        fclose($handle);

        return [
            'success' => true,
            'tables' => implode(', ', $tables_backed),
            'rows' => $total_rows
        ];
    }

    /**
     * Comprimir archivo con gzip
     */
    private function compress_file($filepath)
    {
        if (!function_exists('gzopen')) {
            return $filepath;
        }

        $compressed_path = $filepath . '.gz';
        
        $source = fopen($filepath, 'rb');
        if (!$source) {
            return $filepath;
        }

        $destination = gzopen($compressed_path, 'wb9');
        if (!$destination) {
            fclose($source);
            return $filepath;
        }

        while (!feof($source)) {
            gzwrite($destination, fread($source, 1024 * 512));
        }

        gzclose($destination);
        fclose($source);

        return $compressed_path;
    }

    /**
     * Crear registro del backup en la base de datos
     */
    private function create_backup_record($filename, $filepath, $type)
    {
        $result = $this->wpdb->insert(
            $this->wpdb->prefix . 'mbp_backups',
            [
                'file_name' => $filename,
                'file_path' => $filepath,
                'status' => 'pending',
                'type' => $type,
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );

        return $result ? $this->wpdb->insert_id : false;
    }

    /**
     * Actualizar registro del backup
     */
    private function update_backup_record($id, $data)
    {
        $this->wpdb->update(
            $this->wpdb->prefix . 'mbp_backups',
            $data,
            ['id' => $id],
            null,
            ['%d']
        );
    }

    /**
     * Obtener lista de backups
     */
    public function get_all_backups($limit = 100)
    {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}mbp_backups ORDER BY created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Obtener un backup específico
     */
    public function get_backup($id)
    {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->wpdb->prefix}mbp_backups WHERE id = %d",
                $id
            ),
            ARRAY_A
        );
    }

    /**
     * Eliminar un backup
     */
    public function delete_backup($id)
    {
        $backup = $this->get_backup($id);
        
        if (!$backup) {
            return ['success' => false, 'message' => 'Backup no encontrado'];
        }

        // Eliminar archivo local
        if (!empty($backup['file_path']) && file_exists($backup['file_path'])) {
            @unlink($backup['file_path']);
        }

        // Eliminar de S3 si existe
        if (!empty($backup['s3_key']) && $this->s3_handler->is_configured()) {
            $this->s3_handler->delete_file($backup['s3_key']);
        }

        // Eliminar registro de la base de datos
        $this->wpdb->delete(
            $this->wpdb->prefix . 'mbp_backups',
            ['id' => $id],
            ['%d']
        );

        return ['success' => true, 'message' => 'Backup eliminado correctamente'];
    }

    /**
     * Obtener URL de descarga
     */
    public function get_download_url($id)
    {
        $backup = $this->get_backup($id);
        
        if (!$backup) {
            return ['success' => false, 'message' => 'Backup no encontrado'];
        }

        // Si está en S3, generar URL presignada
        if (!empty($backup['s3_key']) && $this->s3_handler->is_configured()) {
            return $this->s3_handler->get_presigned_url($backup['s3_key']);
        }

        // Descarga local
        if (!empty($backup['file_path']) && file_exists($backup['file_path'])) {
            // Crear URL temporal segura
            $token = wp_create_nonce('mbp_download_' . $id);
            set_transient('mbp_download_' . $id, true, MINUTE_IN_SECONDS * 5);
            
            return [
                'success' => true,
                'type' => 'local',
                'url' => admin_url('admin-ajax.php?action=mbp_download_local&id=' . $id . '&token=' . $token),
                'filename' => basename($backup['file_path'])
            ];
        }

        return ['success' => false, 'message' => 'Archivo no disponible'];
    }

    /**
     * Restaurar un backup
     */
    public function restore_backup($id)
    {
        $backup = $this->get_backup($id);
        
        if (!$backup) {
            return ['success' => false, 'message' => 'Backup no encontrado'];
        }

        $filepath = $backup['file_path'];
        
        // Si está comprimido, descomprimir
        if (strpos($filepath, '.gz') !== false) {
            $filepath = $this->decompress_file($filepath);
        }

        if (!file_exists($filepath)) {
            return ['success' => false, 'message' => 'Archivo de backup no encontrado'];
        }

        // Leer y ejecutar el SQL
        $sql_content = file_get_contents($filepath);
        if (!$sql_content) {
            return ['success' => false, 'message' => 'No se pudo leer el archivo de backup'];
        }

        // Dividir en sentencias
        $statements = $this->split_sql_statements($sql_content);
        $executed = 0;
        $failed = 0;

        foreach ($statements as $statement) {
            $statement = trim($statement);
            if (empty($statement)) {
                continue;
            }

            $result = $this->wpdb->query($statement);
            if ($result === false) {
                $failed++;
            } else {
                $executed++;
            }
        }

        return [
            'success' => true,
            'message' => "Restauración completada. {$executed} sentencias ejecutadas, {$failed} fallidas.",
            'executed' => $executed,
            'failed' => $failed
        ];
    }

    /**
     * Descomprimir archivo gzip
     */
    private function decompress_file($filepath)
    {
        if (!function_exists('gzopen')) {
            return $filepath;
        }

        $decompressed_path = str_replace('.gz', '', $filepath);
        
        $source = gzopen($filepath, 'rb');
        if (!$source) {
            return $filepath;
        }

        $destination = fopen($decompressed_path, 'wb');
        if (!$destination) {
            gzclose($source);
            return $filepath;
        }

        while (!gzeof($source)) {
            fwrite($destination, gzread($source, 1024 * 512));
        }

        gzclose($source);
        fclose($destination);

        return $decompressed_path;
    }

    /**
     * Dividir contenido SQL en sentencias individuales
     */
    private function split_sql_statements($sql)
    {
        $statements = [];
        $current = '';
        
        // PHP 8.4+ compat: ensure we handle large strings and potential nulls
        $sql_str = (string)$sql;
        $length = strlen($sql_str);
        $in_string = false;
        $string_char = '';
        $i = 0;

        while ($i < $length) {
            $char = $sql_str[$i];
            $current .= $char;

            if ($in_string) {
                if ($char === '\\' && $i + 1 < $length) {
                    $current .= $sql_str[++$i];
                } elseif ($char === $string_char) {
                    $in_string = false;
                }
            } else {
                if ($char === "'" || $char === '"' || $char === '`') {
                    $in_string = true;
                    $string_char = $char;
                } elseif ($char === ';') {
                    $statements[] = trim($current);
                    $current = '';
                }
            }

            $i++;
        }

        if (!empty(trim($current))) {
            $statements[] = $current;
        }

        return $statements;
    }

    /**
     * Limpiar backups antiguos según la retención configurada
     */
    private function cleanup_old_backups()
    {
        $retention = intval(get_option('mbp_retention_count', '10'));
        
        if ($retention <= 0) {
            return;
        }

        $old_backups = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT id FROM {$this->wpdb->prefix}mbp_backups 
                 WHERE status = 'completed' 
                 ORDER BY created_at DESC 
                 LIMIT 18446744073709551615 OFFSET %d",
                $retention
            )
        );

        foreach ($old_backups as $backup) {
            $this->delete_backup($backup->id);
        }
    }

    /**
     * Obtener tablas excluidas
     */
    private function get_excluded_tables()
    {
        $excluded = get_option('mbp_exclude_tables', '');
        if (empty($excluded)) {
            return [];
        }
        
        $tables = array_map('trim', explode(',', $excluded));
        global $wpdb;
        $prefix = $wpdb->prefix;
        
        // Convertir nombres sin prefijo a nombres completos
        $full_names = [];
        foreach ($tables as $table) {
            if (strpos($table, $prefix) !== 0) {
                $full_names[] = $prefix . $table;
            } else {
                $full_names[] = $table;
            }
        }
        
        return $full_names;
    }

    /**
     * Formatear bytes
     */
    private function format_bytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= (1 << (10 * $pow));
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}
