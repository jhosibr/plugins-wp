<?php
/**
 * Clase para manejar la activación del plugin
 */
class MBP_Activator
{
    public static function activate()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'mbp_backups';

        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            file_name varchar(255) NOT NULL,
            file_path varchar(500) DEFAULT NULL,
            s3_key varchar(500) DEFAULT NULL,
            s3_bucket varchar(255) DEFAULT NULL,
            s3_region varchar(100) DEFAULT NULL,
            file_size bigint(20) DEFAULT 0,
            tables_backed_up text DEFAULT NULL,
            rows_count bigint(20) DEFAULT 0,
            status varchar(50) DEFAULT 'pending',
            type varchar(50) DEFAULT 'manual',
            error_message text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Insertar opciones por defecto
        self::set_default_options();

        // Programar evento cron si no existe
        if (!wp_next_scheduled('mbp_daily_backup')) {
            wp_schedule_event(time(), 'daily', 'mbp_daily_backup');
        }

        // Crear directorio de backups locales si no existe
        $backup_dir = WP_CONTENT_DIR . '/mysql-backup-pro';
        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
            // Crear archivo .htaccess para proteger el directorio
            $htaccess_content = "Options -Indexes\n\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>";
            file_put_contents($backup_dir . '/.htaccess', $htaccess_content);
        }

        // Crear index.php vacío
        if (!file_exists($backup_dir . '/index.php')) {
            file_put_contents($backup_dir . '/index.php', '<?php // Silence is golden');
        }
    }

    private static function set_default_options()
    {
        $defaults = [
            'mbp_enabled' => '1',
            'mbp_backup_frequency' => 'daily',
            'mbp_backup_time' => '02:00',
            'mbp_backup_type' => 'full',
            'mbp_s3_provider' => 'aws',
            'mbp_s3_region' => 'us-east-1',
            'mbp_s3_bucket' => '',
            'mbp_s3_access_key' => '',
            'mbp_s3_secret_key' => '',
            'mbp_s3_endpoint' => '',
            'mbp_s3_path_style' => '0',
            'mbp_retention_count' => '10',
            'mbp_compress_backup' => '1',
            'mbp_exclude_tables' => '',
            'mbp_notify_email' => get_option('admin_email'),
        ];

        foreach ($defaults as $option => $value) {
            if (get_option($option) === false) {
                add_option($option, $value);
            }
        }
    }
}
