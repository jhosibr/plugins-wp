<?php
/**
 * Clase para manejar la desactivación del plugin
 */
class MBP_Deactivator
{
    public static function deactivate()
    {
        // Limpiar eventos cron
        $timestamp = wp_next_scheduled('mbp_daily_backup');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'mbp_daily_backup');
        }

        // Limpiar otros cron hooks
        wp_clear_scheduled_hook('mbp_daily_backup');
        wp_clear_scheduled_hook('mbp_weekly_backup');
        wp_clear_scheduled_hook('mbp_custom_backup');
    }
}
