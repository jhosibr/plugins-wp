# MySQL Backup Pro

Plugin profesional para WordPress que realiza respaldos automáticos de la base de datos MySQL y los sube a un bucket S3.

## Características

- **Backups Automáticos**: Programa backups con la frecuencia que necesites (hora, diario, semanal, mensual)
- **Subida a S3**: Compatible con AWS S3, MinIO, Wasabi, DigitalOcean Spaces y cualquier servicio S3-compatible
- **Panel de Administración**: Dashboard con estadísticas en tiempo real
- **Listado de Backups**: Historial completo con opciones de descarga y eliminación
- **Compresión Gzip**: Reduce el tamaño de los backups automáticamente
- **Retención Configurable**: Elimina backups antiguos automáticamente
- **Notificaciones por Email**: Recibe alertas de éxito o error
- **Tablero de Pruebas**: Vista de wp_users para verificar integridad de los backups
- **Seguridad**: Credenciales encriptadas y directorio protegido

## Instalación

### Método 1: Instalación Manual

1. Descarga el archivo ZIP del plugin
2. Ve a WordPress Admin > Plugins > Añadir nuevo > Subir plugin
3. Selecciona el archivo ZIP y haz clic en "Instalar ahora"
4. Activa el plugin

### Método 2: Instalación por FTP

1. Extrae el archivo ZIP
2. Sube la carpeta `mysql-backup-pro` a `/wp-content/plugins/`
3. Ve a WordPress Admin > Plugins y activa "MySQL Backup Pro"

### Método 3: Instalar AWS SDK (Recomendado para S3)

Para usar la funcionalidad de S3, necesitas instalar el AWS SDK:

1. Conecta a tu servidor por SSH
2. Navega al directorio del plugin:
   ```bash
   cd /ruta/a/wordpress/wp-content/plugins/mysql-backup-pro
   ```
3. Instala las dependencias con Composer:
   ```bash
   composer install --no-dev
   ```

Si no tienes Composer instalado, puedes descargar el AWS SDK manualmente o usar el backup local.

## Configuración

1. Ve a **MySQL Backup Pro > Configuración**
2. Configura la frecuencia de backups
3. Introduce los datos de tu bucket S3:
   - **Proveedor**: Selecciona tu servicio (AWS, MinIO, Wasabi, etc.)
   - **Región**: La región de tu bucket
   - **Bucket**: Nombre del bucket
   - **Access Key** y **Secret Key**: Credenciales de acceso
4. Para servicios no-AWS, introduce el endpoint URL
5. Guarda la configuración y prueba la conexión

## Uso

### Dashboard
El panel principal muestra estadísticas de backups, información de la base de datos y acceso rápido a las funciones principales.

### Realizar un Backup Manual
1. Ve a **MySQL Backup Pro > Backups**
2. Haz clic en "Ejecutar Backup Ahora"
3. Espera a que el proceso termine

### Ver Backups
En **MySQL Backup Pro > Backups** puedes ver el historial completo, descargar archivos o eliminar backups antiguos.

### Modo de Pruebas
En **MySQL Backup Pro > WP Users (Test)** puedes ver la tabla `wp_users` para verificar que los backups incluyen los datos correctamente.

## Frecuencias de Backup Disponibles

- Cada hora
- Cada 6 horas
- Cada 12 horas
- Dos veces al día
- Diario
- Semanal
- Mensual

## Proveedores S3 Compatibles

- Amazon Web Services (AWS)
- MinIO
- Wasabi
- DigitalOcean Spaces
- Cualquier servicio S3-compatible

## Seguridad

- Las credenciales de S3 se almacenan encriptadas en la base de datos
- El directorio de backups está protegido con .htaccess
- Solo usuarios con rol `manage_options` pueden acceder al plugin
- Las URLs de descarga usan tokens de seguridad temporales

## Solución de Problemas

### Error: "Cliente S3 no disponible"
Instala el AWS SDK ejecutando `composer install` en el directorio del plugin.

### Los backups no se ejecutan automáticamente
Asegúrate de que WP Cron esté funcionando correctamente. Puedes verificarlo en el Dashboard del plugin.

### Error de memoria
Para bases de datos grandes, aumenta el límite de memoria en `wp-config.php`:
```php
define('WP_MEMORY_LIMIT', '512M');
```

## Requisitos

- WordPress 5.8 o superior
- PHP 7.4 o superior
- Extensión `mysqli` de PHP
- Extensión `openssl` para encriptación
- Extensión `zlib` para compresión gzip (opcional)
- Composer (solo para instalar AWS SDK)

## Licencia

GPL v2 o posterior

## Créditos

Desarrollado por el equipo de MySQL Backup Pro
