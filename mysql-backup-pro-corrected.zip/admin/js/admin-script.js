/**
 * MySQL Backup Pro - Admin Scripts
 */

(function($) {
    'use strict';

    // Document Ready
    $(document).ready(function() {
        initBackupHandlers();
        initSettingsHandlers();
        initSearchHandlers();
        initTableActions();
    });

    // ===== Handlers de Backup =====
    function initBackupHandlers() {
        // Ejecutar backup
        $(document).on('click', '#mbp-run-backup', function(e) {
            e.preventDefault();
            runBackup();
        });

        // Refrescar lista de backups
        $(document).on('click', '#mbp-refresh-list', function(e) {
            e.preventDefault();
            refreshBackupsList();
        });
    }

    // ===== Handlers de Settings =====
    function initSettingsHandlers() {
        // Mostrar/ocultar campo de tablas excluidas
        $(document).on('change', '#mbp_backup_type', function() {
            if ($(this).val() === 'custom') {
                $('#exclude-tables-row').slideDown();
            } else {
                $('#exclude-tables-row').slideUp();
            }
        });

        // Mostrar/ocultar campos de endpoint
        $(document).on('change', '#mbp_s3_provider', function() {
            if ($(this).val() === 'aws') {
                $('.mbp-endpoint-row').slideUp();
            } else {
                $('.mbp-endpoint-row').slideDown();
            }
        });

        // Probar conexión S3
        $(document).on('click', '#mbp-test-connection', function(e) {
            e.preventDefault();
            testS3Connection();
        });

        // Guardar settings via AJAX
        $(document).on('submit', '#mbp-settings-form', function(e) {
            e.preventDefault();
            saveSettings();
        });
    }

    // ===== Handlers de Búsqueda =====
    function initSearchHandlers() {
        // Buscar en tabla de usuarios
        $(document).on('input', '#mbp-user-search', function() {
            var searchTerm = $(this).val().toLowerCase();
            
            $('#mbp-users-table tbody tr').each(function() {
                var text = $(this).text().toLowerCase();
                if (text.indexOf(searchTerm) > -1) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    }

    // ===== Handlers de Tablas =====
    function initTableActions() {
        // Descargar backup
        $(document).on('click', '.mbp-download', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            downloadBackup(id);
        });

        // Eliminar backup
        $(document).on('click', '.mbp-delete', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            deleteBackup(id);
        });
    }

    // ===== Funciones =====

    /**
     * Ejecutar backup manual
     */
    function runBackup() {
        if (!confirm('¿Deseas ejecutar un backup ahora? Esto puede tardar varios minutos dependiendo del tamaño de la base de datos.')) {
            return;
        }

        // Mostrar modal de progreso
        var $modal = $('#mbp-progress-modal');
        var $fill = $modal.find('.mbp-progress-fill');
        var $status = $modal.find('.mbp-progress-status');
        
        $modal.show();
        $fill.removeClass('complete').addClass('active');
        $status.text(mbp_ajax.strings.backupStarted);

        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_run_backup',
                nonce: mbp_ajax.nonce
            },
            success: function(response) {
                $fill.addClass('complete');
                
                if (response.success) {
                    var data = response.data;
                    var message = mbp_ajax.strings.backupSuccess + '\n' +
                        'Archivo: ' + data.filename + '\n' +
                        'Tamaño: ' + data.file_size + '\n' +
                        'Duración: ' + data.duration + ' segundos';
                    
                    if (data.s3_uploaded) {
                        message += '\nSubido a S3: Sí';
                    }
                    
                    alert(message);
                    refreshBackupsList();
                } else {
                    alert(mbp_ajax.strings.backupError + ': ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                alert(mbp_ajax.strings.backupError + ': ' + error);
            },
            complete: function() {
                setTimeout(function() {
                    $modal.hide();
                    $fill.removeClass('active complete');
                }, 1000);
            }
        });
    }

    /**
     * Refrescar lista de backups
     */
    function refreshBackupsList() {
        var $button = $('#mbp-refresh-list');
        var $table = $('#mbp-backups-table tbody');
        
        $button.prop('disabled', true).addClass('mbp-loading');

        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_get_backups',
                nonce: mbp_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateBackupsTable(response.data.backups);
                }
            },
            complete: function() {
                $button.prop('disabled', false).removeClass('mbp-loading');
            }
        });
    }

    /**
     * Actualizar tabla de backups
     */
    function updateBackupsTable(backups) {
        var $tbody = $('#mbp-backups-table tbody');
        
        if (!backups || backups.length === 0) {
            $tbody.html(
                '<tr class="mbp-no-backups"><td colspan="10">' +
                '<div class="mbp-empty-state"><span class="dashicons dashicons-backup"></span>' +
                '<p>No hay backups registrados.</p></div></td></tr>'
            );
            return;
        }

        var html = '';
        backups.forEach(function(backup) {
            var date = backup.completed_at || backup.created_at;
            var s3Icon = backup.s3_key 
                ? '<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>'
                : '<span class="dashicons dashicons-minus" style="color: #ccc;"></span>';
            
            var tables = backup.tables_backed_up ? backup.tables_backed_up.split(', ').length : 0;
            
            html += '<tr data-id="' + backup.id + '">' +
                '<td>' + backup.id + '</td>' +
                '<td><code>' + escapeHtml(backup.file_name) + '</code></td>' +
                '<td>' + formatBytes(backup.file_size) + '</td>' +
                '<td>' + tables + ' tablas</td>' +
                '<td>' + numberFormat(backup.rows_count) + '</td>' +
                '<td><span class="mbp-type mbp-type-' + backup.type + '">' + capitalize(backup.type) + '</span></td>' +
                '<td><span class="mbp-status mbp-status-' + backup.status + '">' + capitalize(backup.status) + '</span></td>' +
                '<td>' + s3Icon + '</td>' +
                '<td>' + formatDate(date) + '</td>' +
                '<td>' +
                    '<div class="mbp-row-actions">' +
                        '<button type="button" class="button button-small mbp-download" data-id="' + backup.id + '" title="Descargar"><span class="dashicons dashicons-download"></span></button>' +
                        '<button type="button" class="button button-small mbp-delete" data-id="' + backup.id + '" title="Eliminar"><span class="dashicons dashicons-trash"></span></button>' +
                    '</div>' +
                '</td>' +
            '</tr>';
        });

        $tbody.html(html);
    }

    /**
     * Descargar backup
     */
    function downloadBackup(id) {
        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_download_backup',
                nonce: mbp_ajax.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    
                    if (data.type === 's3') {
                        // Abrir URL presignada en nueva pestaña
                        window.open(data.url, '_blank');
                    } else if (data.type === 'local') {
                        // Descargar archivo local
                        var link = document.createElement('a');
                        link.href = data.url;
                        link.download = data.filename;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al obtener el enlace de descarga: ' + error);
            }
        });
    }

    /**
     * Eliminar backup
     */
    function deleteBackup(id) {
        if (!confirm('¿Estás seguro de que deseas eliminar este backup? Esta acción no se puede deshacer.')) {
            return;
        }

        var $button = $('.mbp-delete[data-id="' + id + '"]');
        $button.prop('disabled', true);

        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_delete_backup',
                nonce: mbp_ajax.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    $('tr[data-id="' + id + '"]').fadeOut(300, function() {
                        $(this).remove();
                    });
                    alert(mbp_ajax.strings.deleteSuccess);
                } else {
                    alert('Error: ' + response.data);
                    $button.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al eliminar: ' + error);
                $button.prop('disabled', false);
            }
        });
    }

    /**
     * Probar conexión S3
     */
    function testS3Connection() {
        var $button = $('#mbp-test-connection');
        var $result = $('#mbp-test-result');
        
        $button.prop('disabled', true);
        $result.hide().removeClass('success error');

        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_test_connection',
                nonce: mbp_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.addClass('success').text(response.data.message).show();
                } else {
                    $result.addClass('error').text(response.data).show();
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('Error de conexión: ' + error).show();
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    }

    /**
     * Guardar configuración
     */
    function saveSettings() {
        var $form = $('#mbp-settings-form');
        var $submit = $form.find('button[type="submit"]');
        
        $submit.prop('disabled', true).addClass('mbp-loading');

        $.ajax({
            url: mbp_ajax.ajax_url,
            type: 'POST',
            data: $form.serialize() + '&action=mbp_save_settings&nonce=' + mbp_ajax.nonce,
            success: function(response) {
                if (response.success) {
                    alert(mbp_ajax.strings.settingsSaved);
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                alert('Error al guardar: ' + error);
            },
            complete: function() {
                $submit.prop('disabled', false).removeClass('mbp-loading');
            }
        });
    }

    // ===== Utilidades =====

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        var k = 1024;
        var sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function numberFormat(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function formatDate(dateString) {
        if (!dateString) return '-';
        var date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString;
        return date.toLocaleString('es-ES', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

})(jQuery);
