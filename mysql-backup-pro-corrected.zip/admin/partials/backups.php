<?php
// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

$backup = new MBP_Backup();
$backups = $backup->get_all_backups();
?>

<div class="wrap mbp-backups">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <!-- Acciones -->
    <div class="mbp-toolbar">
        <button type="button" id="mbp-run-backup" class="button button-primary">
            <span class="dashicons dashicons-cloud-upload"></span>
            <?php _e('Ejecutar Backup Ahora', 'mysql-backup-pro'); ?>
        </button>
        <button type="button" id="mbp-refresh-list" class="button button-secondary">
            <span class="dashicons dashicons-update"></span>
            <?php _e('Actualizar Lista', 'mysql-backup-pro'); ?>
        </button>
    </div>

    <!-- Tabla de Backups -->
    <div class="mbp-table-wrapper">
        <table class="widefat mbp-backups-table" id="mbp-backups-table">
            <thead>
                <tr>
                    <th><?php _e('ID', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Archivo', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Tamaño', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Tablas', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Filas', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Tipo', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Estado', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('S3', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Fecha', 'mysql-backup-pro'); ?></th>
                    <th><?php _e('Acciones', 'mysql-backup-pro'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($backups)) : ?>
                    <?php foreach ($backups as $item) : ?>
                        <tr data-id="<?php echo intval($item['id']); ?>">
                            <td><?php echo intval($item['id']); ?></td>
                            <td>
                                <code><?php echo esc_html($item['file_name']); ?></code>
                            </td>
                            <td><?php echo MBP_Admin::get_instance()->format_bytes(intval($item['file_size'])); ?></td>
                            <td>
                                <?php 
                                $tables = $item['tables_backed_up'] ? explode(', ', $item['tables_backed_up']) : [];
                                echo count($tables) . ' ' . __('tablas', 'mysql-backup-pro');
                                ?>
                            </td>
                            <td><?php echo number_format(intval($item['rows_count'])); ?></td>
                            <td>
                                <span class="mbp-type mbp-type-<?php echo esc_attr($item['type']); ?>">
                                    <?php echo esc_html(ucfirst($item['type'])); ?>
                                </span>
                            </td>
                            <td>
                                <span class="mbp-status mbp-status-<?php echo esc_attr($item['status']); ?>">
                                    <?php echo esc_html(ucfirst($item['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($item['s3_key'])) : ?>
                                    <span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span>
                                <?php else : ?>
                                    <span class="dashicons dashicons-minus" style="color: #ccc;"></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                $date = $item['completed_at'] ? $item['completed_at'] : $item['created_at'];
                                echo esc_html(date_i18n('Y-m-d H:i', strtotime($date)));
                                ?>
                            </td>
                            <td>
                                <div class="mbp-row-actions">
                                    <button type="button" class="button button-small mbp-download" data-id="<?php echo intval($item['id']); ?>" title="<?php _e('Descargar', 'mysql-backup-pro'); ?>">
                                        <span class="dashicons dashicons-download"></span>
                                    </button>
                                    <button type="button" class="button button-small mbp-delete" data-id="<?php echo intval($item['id']); ?>" title="<?php _e('Eliminar', 'mysql-backup-pro'); ?>">
                                        <span class="dashicons dashicons-trash"></span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr class="mbp-no-backups">
                        <td colspan="10">
                            <div class="mbp-empty-state">
                                <span class="dashicons dashicons-backup"></span>
                                <p><?php _e('No hay backups registrados.', 'mysql-backup-pro'); ?></p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de progreso -->
    <div id="mbp-progress-modal" class="mbp-modal" style="display: none;">
        <div class="mbp-modal-content">
            <h2><?php _e('Ejecutando Backup...', 'mysql-backup-pro'); ?></h2>
            <div class="mbp-progress-bar">
                <div class="mbp-progress-fill"></div>
            </div>
            <p class="mbp-progress-status"><?php _e('Iniciando...', 'mysql-backup-pro'); ?></p>
        </div>
    </div>
</div>
