<?php
// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

$settings = MBP_Admin::get_instance()->get_settings();
$admin = MBP_Admin::get_instance();

// Frecuencias disponibles
$frequencies = [
    'hourly' => __('Cada hora', 'mysql-backup-pro'),
    'every_6_hours' => __('Cada 6 horas', 'mysql-backup-pro'),
    'every_12_hours' => __('Cada 12 horas', 'mysql-backup-pro'),
    'twicedaily' => __('Dos veces al día', 'mysql-backup-pro'),
    'daily' => __('Diario', 'mysql-backup-pro'),
    'weekly' => __('Semanal', 'mysql-backup-pro'),
    'monthly' => __('Mensual', 'mysql-backup-pro'),
];

// Tipos de backup
$backup_types = [
    'full' => __('Completo (todas las tablas)', 'mysql-backup-pro'),
    'custom' => __('Personalizado (excluir tablas)', 'mysql-backup-pro'),
];

// Providers S3
$s3_providers = [
    'aws' => __('Amazon Web Services (AWS)', 'mysql-backup-pro'),
    'contabo' => __('Contabo S3', 'mysql-backup-pro'),
    'minio' => __('MinIO', 'mysql-backup-pro'),
    'wasabi' => __('Wasabi', 'mysql-backup-pro'),
    'digitalocean' => __('DigitalOcean Spaces', 'mysql-backup-pro'),
    'other' => __('Otro (compatible S3)', 'mysql-backup-pro'),
];

// Regiones AWS
$aws_regions = [
    'us-east-1' => 'US East (N. Virginia)',
    'us-east-2' => 'US East (Ohio)',
    'us-west-1' => 'US West (N. California)',
    'us-west-2' => 'US West (Oregon)',
    'ca-central-1' => 'Canada (Central)',
    'eu-west-1' => 'Europe (Ireland)',
    'eu-west-2' => 'Europe (London)',
    'eu-west-3' => 'Europe (Paris)',
    'eu-central-1' => 'Europe (Frankfurt)',
    'eu-north-1' => 'Europe (Stockholm)',
    'ap-southeast-1' => 'Asia Pacific (Singapore)',
    'ap-southeast-2' => 'Asia Pacific (Sydney)',
    'ap-northeast-1' => 'Asia Pacific (Tokyo)',
    'ap-northeast-2' => 'Asia Pacific (Seoul)',
    'ap-south-1' => 'Asia Pacific (Mumbai)',
    'sa-east-1' => 'South America (São Paulo)',
];
?>

<div class="wrap mbp-settings">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <form id="mbp-settings-form" method="post">
        <?php wp_nonce_field('mbp_save_settings', 'mbp_settings_nonce'); ?>

        <!-- General Settings -->
        <div class="mbp-section">
            <h2><?php _e('Configuración General', 'mysql-backup-pro'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="mbp_enabled"><?php _e('Backups Automáticos', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" id="mbp_enabled" name="mbp_enabled" value="1" <?php checked($settings['enabled'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description"><?php _e('Activar o desactivar los backups automáticos.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_backup_frequency"><?php _e('Frecuencia de Backups', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <select id="mbp_backup_frequency" name="mbp_backup_frequency" class="regular-text">
                            <?php foreach ($frequencies as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['backup_frequency'], $value); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php _e('Con qué frecuencia se realizarán los backups automáticos.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_backup_time"><?php _e('Hora del Backup', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="time" id="mbp_backup_time" name="mbp_backup_time" value="<?php echo esc_attr($settings['backup_time']); ?>" class="regular-text">
                        <p class="description"><?php _e('Hora a la que se ejecutará el backup (formato 24h).', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_backup_type"><?php _e('Tipo de Backup', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <select id="mbp_backup_type" name="mbp_backup_type" class="regular-text">
                            <?php foreach ($backup_types as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['backup_type'], $value); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php _e('Seleccione si desea respaldar todas las tablas o excluir algunas.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr id="exclude-tables-row" style="<?php echo $settings['backup_type'] === 'custom' ? '' : 'display: none;'; ?>">
                    <th scope="row">
                        <label for="mbp_exclude_tables"><?php _e('Tablas a Excluir', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <textarea id="mbp_exclude_tables" name="mbp_exclude_tables" rows="4" class="large-text code" placeholder="wp_options, wp_postmeta, wp_comments"><?php echo esc_textarea($settings['exclude_tables']); ?></textarea>
                        <p class="description"><?php _e('Lista de tablas a excluir separadas por comas. Puede usar nombres con o sin prefijo.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_compress_backup"><?php _e('Comprimir Backups', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" id="mbp_compress_backup" name="mbp_compress_backup" value="1" <?php checked($settings['compress_backup'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description"><?php _e('Comprimir los archivos de backup con gzip para reducir el tamaño.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_retention_count"><?php _e('Retención de Backups', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="number" id="mbp_retention_count" name="mbp_retention_count" value="<?php echo esc_attr($settings['retention_count']); ?>" min="1" max="100" class="small-text">
                        <p class="description"><?php _e('Número máximo de backups a mantener. Los más antiguos se eliminarán automáticamente.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_notify_email"><?php _e('Email de Notificación', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="email" id="mbp_notify_email" name="mbp_notify_email" value="<?php echo esc_attr($settings['notify_email']); ?>" class="regular-text">
                        <p class="description"><?php _e('Dirección de email para recibir notificaciones de backups.', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- S3 Settings -->
        <div class="mbp-section">
            <h2><?php _e('Configuración del Bucket S3', 'mysql-backup-pro'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="mbp_s3_provider"><?php _e('Proveedor S3', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <select id="mbp_s3_provider" name="mbp_s3_provider" class="regular-text">
                            <?php foreach ($s3_providers as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['s3_provider'], $value); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_s3_region"><?php _e('Región', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <select id="mbp_s3_region" name="mbp_s3_region" class="regular-text">
                            <?php foreach ($aws_regions as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($settings['s3_region'], $value); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_s3_bucket"><?php _e('Nombre del Bucket', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="mbp_s3_bucket" name="mbp_s3_bucket" value="<?php echo esc_attr($settings['s3_bucket']); ?>" class="regular-text" placeholder="mi-bucket-backups">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_s3_access_key"><?php _e('Access Key', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="password" id="mbp_s3_access_key" name="mbp_s3_access_key" value="<?php echo esc_attr($settings['s3_access_key']); ?>" class="regular-text" autocomplete="off">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="mbp_s3_secret_key"><?php _e('Secret Key', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="password" id="mbp_s3_secret_key" name="mbp_s3_secret_key" value="<?php echo esc_attr($settings['s3_secret_key']); ?>" class="regular-text" autocomplete="off">
                    </td>
                </tr>

                <tr class="mbp-endpoint-row" style="<?php echo $settings['s3_provider'] !== 'aws' ? '' : 'display: none;'; ?>">
                    <th scope="row">
                        <label for="mbp_s3_endpoint"><?php _e('Endpoint URL', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="mbp_s3_endpoint" name="mbp_s3_endpoint" value="<?php echo esc_attr($settings['s3_endpoint']); ?>" class="regular-text" placeholder="https://s3.example.com">
                        <p class="description"><?php _e('URL del endpoint S3 (solo para servicios no-AWS).', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>

                <tr class="mbp-endpoint-row" style="<?php echo $settings['s3_provider'] !== 'aws' ? '' : 'display: none;'; ?>">
                    <th scope="row">
                        <label for="mbp_s3_path_style"><?php _e('Path Style', 'mysql-backup-pro'); ?></label>
                    </th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" id="mbp_s3_path_style" name="mbp_s3_path_style" value="1" <?php checked($settings['s3_path_style'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description"><?php _e('Usar path-style en lugar de virtual-hosted style (requerido para MinIO).', 'mysql-backup-pro'); ?></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="button" id="mbp-test-connection" class="button button-secondary">
                    <span class="dashicons dashicons-admin-site-alt3"></span>
                    <?php _e('Probar Conexión S3', 'mysql-backup-pro'); ?>
                </button>
                <span id="mbp-test-result" style="margin-left: 10px; display: none;"></span>
            </p>
        </div>

        <!-- Botones -->
        <p class="submit">
            <button type="submit" name="mbp_save_settings" class="button button-primary button-lg">
                <span class="dashicons dashicons-saved"></span>
                <?php _e('Guardar Configuración', 'mysql-backup-pro'); ?>
            </button>
        </p>
    </form>
</div>
