<?php
// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Obtener usuarios de la tabla wp_users
$users = get_users([
    'number' => -1,
    'orderby' => 'ID',
    'order' => 'ASC',
]);

$total_users = count($users);
$roles = wp_roles()->get_names();
?>

<div class="wrap mbp-users">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <!-- Banner informativo -->
    <div class="mbp-notice mbp-notice-info">
        <p>
            <span class="dashicons dashicons-info"></span>
            <strong><?php _e('Modo de Pruebas:', 'mysql-backup-pro'); ?></strong> 
            <?php _e('Esta vista muestra la tabla wp_users actual de la base de datos. Utilice esta información para verificar que los backups contienen los datos correctos.', 'mysql-backup-pro'); ?>
        </p>
    </div>

    <!-- Estadísticas rápidas -->
    <div class="mbp-stats-grid mbp-stats-sm">
        <div class="mbp-stat-card">
            <div class="mbp-stat-icon mbp-stat-primary">
                <span class="dashicons dashicons-groups"></span>
            </div>
            <div class="mbp-stat-content">
                <h3><?php echo number_format($total_users); ?></h3>
                <p><?php _e('Usuarios Totales', 'mysql-backup-pro'); ?></p>
            </div>
        </div>

        <?php
        // Contar usuarios por rol
        $role_counts = [];
        foreach ($users as $user) {
            $user_roles = $user->roles;
            foreach ($user_roles as $role) {
                if (!isset($role_counts[$role])) {
                    $role_counts[$role] = 0;
                }
                $role_counts[$role]++;
            }
        }
        
        $colors = ['success', 'info', 'warning', 'danger'];
        $i = 0;
        foreach ($role_counts as $role => $count) :
            $color = $colors[$i % count($colors)];
            $role_label = isset($roles[$role]) ? translate_user_role($roles[$role]) : ucfirst($role);
        ?>
            <div class="mbp-stat-card">
                <div class="mbp-stat-icon mbp-stat-<?php echo $color; ?>">
                    <span class="dashicons dashicons-admin-users"></span>
                </div>
                <div class="mbp-stat-content">
                    <h3><?php echo number_format($count); ?></h3>
                    <p><?php echo esc_html($role_label); ?></p>
                </div>
            </div>
        <?php 
            $i++;
        endforeach; 
        ?>
    </div>

    <!-- Tabla de usuarios -->
    <div class="mbp-section">
        <h2><?php _e('Lista de Usuarios (wp_users)', 'mysql-backup-pro'); ?></h2>
        
        <div class="mbp-toolbar">
            <input type="text" id="mbp-user-search" class="regular-text" placeholder="<?php _e('Buscar usuario...', 'mysql-backup-pro'); ?>">
            <button type="button" id="mbp-refresh-users" class="button button-secondary">
                <span class="dashicons dashicons-update"></span>
                <?php _e('Actualizar', 'mysql-backup-pro'); ?>
            </button>
        </div>

        <div class="mbp-table-wrapper">
            <table class="widefat mbp-users-table" id="mbp-users-table">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Nombre de Usuario', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Email', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Nombre Completo', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Roles', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Posts', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Registrado', 'mysql-backup-pro'); ?></th>
                        <th><?php _e('Último Login', 'mysql-backup-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($users)) : ?>
                        <?php foreach ($users as $user) : 
                            $user_meta = get_user_meta($user->ID);
                            $first_name = isset($user_meta['first_name'][0]) ? $user_meta['first_name'][0] : '';
                            $last_name = isset($user_meta['last_name'][0]) ? $user_meta['last_name'][0] : '';
                            $full_name = trim($first_name . ' ' . $last_name);
                            $post_count = count_user_posts($user->ID);
                            
                            // Obtener último login si está disponible
                            $last_login = isset($user_meta['wp_last_login'][0]) ? $user_meta['wp_last_login'][0] : '';
                        ?>
                            <tr>
                                <td><?php echo intval($user->ID); ?></td>
                                <td>
                                    <strong><?php echo esc_html($user->user_login); ?></strong>
                                    <?php if ($user->ID === get_current_user_id()) : ?>
                                        <span class="mbp-badge"><?php _e('Tú', 'mysql-backup-pro'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                                        <?php echo esc_html($user->user_email); ?>
                                    </a>
                                </td>
                                <td><?php echo esc_html($full_name); ?></td>
                                <td>
                                    <?php 
                                    if (!empty($user->roles)) {
                                        foreach ($user->roles as $role) {
                                            $role_label = isset($roles[$role]) ? translate_user_role($roles[$role]) : ucfirst($role);
                                            echo '<span class="mbp-role-badge mbp-role-' . esc_attr($role) . '">' . esc_html($role_label) . '</span>';
                                        }
                                    }
                                    ?>
                                </td>
                                <td><?php echo number_format($post_count); ?></td>
                                <td><?php echo esc_html(date_i18n('Y-m-d H:i', strtotime($user->user_registered))); ?></td>
                                <td>
                                    <?php 
                                    if ($last_login) {
                                        echo esc_html(human_time_diff(strtotime($last_login), current_time('timestamp')) . ' ' . __('atrás', 'mysql-backup-pro'));
                                    } else {
                                        echo '<em>' . __('No disponible', 'mysql-backup-pro') . '</em>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="8">
                                <div class="mbp-empty-state">
                                    <span class="dashicons dashicons-groups"></span>
                                    <p><?php _e('No hay usuarios registrados.', 'mysql-backup-pro'); ?></p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Información de la tabla -->
    <div class="mbp-section">
        <h2><?php _e('Información de la Tabla wp_users', 'mysql-backup-pro'); ?></h2>
        <table class="widefat mbp-info-table">
            <tbody>
                <tr>
                    <th><?php _e('Nombre de la Tabla:', 'mysql-backup-pro'); ?></th>
                    <td><code><?php global $wpdb; echo $wpdb->prefix; ?>users</code></td>
                </tr>
                <tr>
                    <th><?php _e('Total de Registros:', 'mysql-backup-pro'); ?></th>
                    <td><?php echo number_format($total_users); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Verificar en Backup:', 'mysql-backup-pro'); ?></th>
                    <td>
                        <?php _e('Después de realizar un backup, descargue el archivo SQL y busque los INSERT INTO para verificar que los datos de usuarios se incluyen correctamente.', 'mysql-backup-pro'); ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
