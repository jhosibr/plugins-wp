<?php
// Prevenir acceso directo
if (!defined('ABSPATH')) {
    exit;
}

$stats = MBP_Admin::get_instance()->get_settings();
$admin = MBP_Admin::get_instance();
$backup_stats = $admin->get_stats();
?>

<div class="wrap mbp-dashboard">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="mbp-stats-grid">
        <!-- Total Backups -->
        <div class="mbp-stat-card">
            <div class="mbp-stat-icon mbp-stat-primary">
                <span class="dashicons dashicons-database"></span>
            </div>
            <div class="mbp-stat-content">
                <h3><?php echo intval($backup_stats['total_backups']); ?></h3>
                <p><?php _e('Total Backups', 'mysql-backup-pro'); ?></p>
            </div>
        </div>

        <!-- Backups Exitosos -->
        <div class="mbp-stat-card">
            <div class="mbp-stat-icon mbp-stat-success">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="mbp-stat-content">
                <h3><?php echo intval($backup_stats['successful_backups']); ?></h3>
                <p><?php _e('Exitosos', 'mysql-backup-pro'); ?></p>
            </div>
        </div>

        <!-- Backups Fallidos -->
        <div class="mbp-stat-card">
            <div class="mbp-stat-icon mbp-stat-danger">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <div class="mbp-stat-content">
                <h3><?php echo intval($backup_stats['failed_backups']); ?></h3>
                <p><?php _e('Fallidos', 'mysql-backup-pro'); ?></p>
            </div>
        </div>

        <!-- Tamaño Total -->
        <div class="mbp-stat-card">
            <div class="mbp-stat-icon mbp-stat-info">
                <span class="dashicons dashicons-media-document"></span>
            </div>
            <div class="mbp-stat-content">
                <h3><?php echo esc_html($backup_stats['total_size']); ?></h3>
                <p><?php _e('Tamaño Total', 'mysql-backup-pro'); ?></p>
            </div>
        </div>
    </div>

    <!-- Información de la Base de Datos -->
    <div class="mbp-section">
        <h2><?php _e('Información de la Base de Datos', 'mysql-backup-pro'); ?></h2>
        <table class="widefat mbp-info-table">
            <tbody>
                <tr>
                    <th><?php _e('Nombre de la Base de Datos:', 'mysql-backup-pro'); ?></th>
                    <td><code><?php echo esc_html($backup_stats['db_name']); ?></code></td>
                </tr>
                <tr>
                    <th><?php _e('Tamaño de la Base de Datos:', 'mysql-backup-pro'); ?></th>
                    <td><?php echo esc_html($backup_stats['db_size']); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Número de Tablas:', 'mysql-backup-pro'); ?></th>
                    <td><?php echo intval($backup_stats['table_count']); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Próximo Backup:', 'mysql-backup-pro'); ?></th>
                    <td><?php echo esc_html($backup_stats['next_backup']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Último Backup -->
    <div class="mbp-section">
        <h2><?php _e('Último Backup', 'mysql-backup-pro'); ?></h2>
        <?php if ($backup_stats['last_backup']) : ?>
            <table class="widefat mbp-info-table">
                <tbody>
                    <tr>
                        <th><?php _e('Archivo:', 'mysql-backup-pro'); ?></th>
                        <td><?php echo esc_html($backup_stats['last_backup']->file_name); ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Tamaño:', 'mysql-backup-pro'); ?></th>
                        <td><?php echo $admin->format_bytes(intval($backup_stats['last_backup']->file_size)); ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Tablas:', 'mysql-backup-pro'); ?></th>
                        <td><?php echo esc_html($backup_stats['last_backup']->tables_backed_up); ?></td>
                    </tr>
                    <tr>
                        <th><?php _e('Estado:', 'mysql-backup-pro'); ?></th>
                        <td>
                            <span class="mbp-status mbp-status-<?php echo esc_attr($backup_stats['last_backup']->status); ?>">
                                <?php echo esc_html(ucfirst($backup_stats['last_backup']->status)); ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                    <tr>
                        <th><?php _e('Completado:', 'mysql-backup-pro'); ?></th>
                        <td><?php echo esc_html($backup_stats['last_backup']->completed_at); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php else : ?>
            <div class="mbp-empty-state">
                <span class="dashicons dashicons-backup"></span>
                <p><?php _e('Aún no se ha realizado ningún backup.', 'mysql-backup-pro'); ?></p>
                <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-backups'); ?>" class="button button-primary">
                    <?php _e('Realizar Primer Backup', 'mysql-backup-pro'); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Acciones Rápidas -->
    <div class="mbp-section">
        <h2><?php _e('Acciones Rápidas', 'mysql-backup-pro'); ?></h2>
        <div class="mbp-actions">
            <button type="button" id="mbp-run-backup" class="button button-primary button-hero">
                <span class="dashicons dashicons-cloud-upload"></span>
                <?php _e('Ejecutar Backup Ahora', 'mysql-backup-pro'); ?>
            </button>
            <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-settings'); ?>" class="button button-secondary">
                <span class="dashicons dashicons-admin-generic"></span>
                <?php _e('Configurar', 'mysql-backup-pro'); ?>
            </a>
            <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-backups'); ?>" class="button button-secondary">
                <span class="dashicons dashicons-list-view"></span>
                <?php _e('Ver Backups', 'mysql-backup-pro'); ?>
            </a>
        </div>
    </div>

    <!-- Log de eventos recientes -->
    <div class="mbp-section">
        <h2><?php _e('Estado del Sistema', 'mysql-backup-pro'); ?></h2>
        <table class="widefat mbp-info-table">
            <tbody>
                <tr>
                    <th><?php _e('Estado de Backups:', 'mysql-backup-pro'); ?></th>
                    <td>
                        <?php if ($stats['enabled'] === '1') : ?>
                            <span class="mbp-status mbp-status-completed"><?php _e('Activado', 'mysql-backup-pro'); ?></span>
                        <?php else : ?>
                            <span class="mbp-status mbp-status-failed"><?php _e('Desactivado', 'mysql-backup-pro'); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Frecuencia:', 'mysql-backup-pro'); ?></th>
                    <td><?php echo esc_html(ucfirst($stats['backup_frequency'])); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Configuración S3:', 'mysql-backup-pro'); ?></th>
                    <td>
                        <?php 
                        $s3_configured = !empty($stats['s3_bucket']) && !empty($stats['s3_access_key']);
                        if ($s3_configured) : ?>
                            <span class="mbp-status mbp-status-completed">
                                <?php _e('Configurado (', 'mysql-backup-pro'); ?><?php echo esc_html($stats['s3_bucket']); ?>)
                            </span>
                        <?php else : ?>
                            <span class="mbp-status mbp-status-pending"><?php _e('No configurado', 'mysql-backup-pro'); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Compresión:', 'mysql-backup-pro'); ?></th>
                    <td>
                        <?php if ($stats['compress_backup'] === '1') : ?>
                            <span class="mbp-status mbp-status-completed"><?php _e('Activada', 'mysql-backup-pro'); ?></span>
                        <?php else : ?>
                            <span class="mbp-status mbp-status-pending"><?php _e('Desactivada', 'mysql-backup-pro'); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
