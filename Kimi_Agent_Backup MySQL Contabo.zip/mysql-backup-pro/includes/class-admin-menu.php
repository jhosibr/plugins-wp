<?php
namespace MBP;

class AdminMenu
{
    private static ?self $instance = null;

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register']);
    }

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function register(): void
    {
        add_menu_page(
            'MySQL Backup Pro',
            'MySQL Backup Pro',
            'manage_options',
            'mysql-backup-pro',
            [$this, 'page_dashboard'],
            'dashicons-database',
            76
        );

        add_submenu_page('mysql-backup-pro', 'Dashboard', 'Dashboard',
            'manage_options', 'mysql-backup-pro', [$this, 'page_dashboard']);

        add_submenu_page('mysql-backup-pro', 'Backups', 'Backups',
            'manage_options', 'mysql-backup-pro-backups', [$this, 'page_backups']);

        add_submenu_page('mysql-backup-pro', 'Configuración', 'Configuración',
            'manage_options', 'mysql-backup-pro-settings', [$this, 'page_settings']);

        add_submenu_page('mysql-backup-pro', 'WP Users (Test)', 'WP Users (Test)',
            'manage_options', 'mysql-backup-pro-users', [$this, 'page_users']);
    }

    public function page_dashboard(): void
    {
        include MBP_PLUGIN_DIR . 'admin/partials/dashboard.php';
    }
    public function page_backups(): void
    {
        include MBP_PLUGIN_DIR . 'admin/partials/backups.php';
    }
    public function page_settings(): void
    {
        include MBP_PLUGIN_DIR . 'admin/partials/settings.php';
    }
    public function page_users(): void
    {
        include MBP_PLUGIN_DIR . 'admin/partials/users.php';
    }

    /* ---------- helpers para vistas ---------- */
    public static function all_settings(): array
    {
        return [
            'enabled'          => get_option('mbp_enabled', '1'),
            'frequency'        => get_option('mbp_backup_frequency', 'daily'),
            'backup_time'      => get_option('mbp_backup_time', '02:00'),
            's3_endpoint'      => get_option('mbp_s3_endpoint', ''),
            's3_region'        => get_option('mbp_s3_region', 'default'),
            's3_bucket'        => get_option('mbp_s3_bucket', ''),
            's3_access_key'    => Crypto::decrypt(get_option('mbp_s3_access_key', '')),
            's3_secret_key'    => Crypto::decrypt(get_option('mbp_s3_secret_key', '')),
            's3_path_style'    => get_option('mbp_s3_path_style', '1'),
            'retention'        => get_option('mbp_retention_count', '10'),
            'compress'         => get_option('mbp_compress_backup', '1'),
            'notify_email'     => get_option('mbp_notify_email', get_option('admin_email', '')),
        ];
    }

    public static function stats(): array
    {
        global $wpdb;
        $t = $wpdb->prefix . 'mbp_backups';

        $total  = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t}");
        $ok     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='completed'");
        $fail   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='failed'");
        $size   = (int) $wpdb->get_var("SELECT COALESCE(SUM(file_size),0) FROM {$t} WHERE status='completed'");
        $last   = $wpdb->get_row("SELECT * FROM {$t} WHERE status='completed' ORDER BY completed_at DESC LIMIT 1");

        $db_name = DB_NAME;
        $db_size = (int) $wpdb->get_var("SELECT SUM(data_length+index_length) FROM information_schema.tables WHERE table_schema='{$db_name}'");
        $tbl_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{$db_name}' AND table_type='BASE TABLE'");

        return [
            'total_backups' => $total,
            'successful'    => $ok,
            'failed'        => $fail,
            'total_size'    => self::fmt_bytes($size),
            'last_backup'   => $last,
            'db_name'       => $db_name,
            'db_size'       => self::fmt_bytes($db_size),
            'table_count'   => $tbl_cnt,
            'next_backup'   => self::next_backup_human(),
        ];
    }

    public static function fmt_bytes(int $bytes, int $prec = 2): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        if ($bytes <= 0) {
            return '0 B';
        }
        $pow = min((int) floor(log($bytes, 1024)), count($units) - 1);
        return round($bytes / (1024 ** $pow), $prec) . ' ' . $units[$pow];
    }

    private static function next_backup_human(): string
    {
        $ts = wp_next_scheduled('mbp_run_cron_backup');
        return $ts ? wp_date('Y-m-d H:i:s', $ts) : __('No programado', 'mysql-backup-pro');
    }
}
