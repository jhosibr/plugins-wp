/**
 * MySQL Backup Pro - Admin JS
 */
(function($) {

    $(function() {
        initBackup();
        initDownloads();
        initDeletes();
        initSettings();
        initTestS3();
        initSearch();
        initRefresh();
    });

    /* ===== EJECUTAR BACKUP ===== */
    function initBackup() {
        $('#mbp-run-backup').on('click', function(e) {
            e.preventDefault();
            if (!confirm('¿Ejecutar backup ahora? Puede tardar varios minutos.')) return;

            var $modal = $('#mbp-modal').show();
            var $bar   = $modal.find('.mbp-progress-bar').removeClass('success error').addClass('active');
            var $msg   = $('#mbp-modal-msg').text(mbp_ajax.strings.backupStarted);

            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_run_backup',
                nonce : mbp_ajax.nonce,
            }, function(res) {
                if (res.success) {
                    $bar.removeClass('active').addClass('success');
                    $msg.text(mbp_ajax.strings.backupOk);
                    var d = res.data;
                    alert(mbp_ajax.strings.backupOk + '\n\nArchivo: ' + d.filename + '\nTamaño: ' + d.file_size + '\nS3: ' + (d.s3 ? 'Sí' : 'No') + '\nDuración: ' + d.duration + 's');
                    setTimeout(function() { location.reload(); }, 500);
                } else {
                    $bar.removeClass('active').addClass('error');
                    $msg.text(mbp_ajax.strings.backupErr);
                    alert(mbp_ajax.strings.backupErr + '\n' + (res.data || ''));
                }
            }).fail(function() {
                $bar.removeClass('active').addClass('error');
                alert('Error de comunicación con el servidor.');
            }).always(function() {
                setTimeout(function() { $modal.hide(); }, 800);
            });
        });
    }

    /* ===== DESCARGAR ===== */
    function initDownloads() {
        $('.mbp-btn-download').on('click', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            var $btn = $(this).prop('disabled', true);

            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_download_backup',
                nonce : mbp_ajax.nonce,
                id    : id,
            }, function(res) {
                if (res.success) {
                    var d = res.data;
                    if (d.type === 's3') {
                        window.open(d.url, '_blank');
                    } else if (d.type === 'local') {
                        var a = $('<a>').attr({ href: d.url, download: d.filename || '' }).hide().appendTo('body');
                        a[0].click();
                        a.remove();
                    }
                } else {
                    alert('Error: ' + (res.data || 'No se pudo generar enlace'));
                }
            }).fail(function() {
                alert('Error de comunicación');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });
    }

    /* ===== ELIMINAR ===== */
    function initDeletes() {
        $('.mbp-btn-delete').on('click', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (!confirm(mbp_ajax.strings.confirmDelete)) return;

            var $btn = $(this).prop('disabled', true);
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_delete_backup',
                nonce : mbp_ajax.nonce,
                id    : id,
            }, function(res) {
                if (res.success) {
                    $('tr[data-id="' + id + '"]').fadeOut(300, function() { $(this).remove(); });
                } else {
                    alert('Error: ' + (res.data || ''));
                }
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });
    }

    /* ===== GUARDAR CONFIGURACIÓN ===== */
    function initSettings() {
        $('#mbp-settings-form').on('submit', function(e) {
            e.preventDefault();
            var $btn = $(this).find('button[type="submit"]').prop('disabled', true);

            // Serializar formulario
            var data = $(this).serialize();
            data += '&action=mbp_save_settings&nonce=' + encodeURIComponent(mbp_ajax.nonce);

            $.post(mbp_ajax.ajax_url, data, function(res) {
                if (res.success) {
                    alert(mbp_ajax.strings.saved);
                } else {
                    alert('Error: ' + (res.data || ''));
                }
            }).fail(function() {
                alert('Error de comunicación al guardar.');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });
    }

    /* ===== PROBAR CONEXIÓN S3 ===== */
    function initTestS3() {
        $('#mbp-test-s3').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this).prop('disabled', true);
            var $res = $('#mbp-test-result').text('Probando...').show().css('color', '#666');

            // Recoger valores actuales del formulario para la prueba
            var formData = $('#mbp-settings-form').serialize();
            formData += '&action=mbp_test_s3&nonce=' + encodeURIComponent(mbp_ajax.nonce);

            $.post(mbp_ajax.ajax_url, formData, function(r) {
                if (r.success) {
                    $res.text(r.data.message).css('color', '#46b450');
                } else {
                    $res.text(r.data || mbp_ajax.strings.connErr).css('color', '#dc3232');
                }
            }).fail(function(xhr) {
                $res.text('Error HTTP ' + xhr.status).css('color', '#dc3232');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });
    }

    /* ===== BUSCAR USUARIOS ===== */
    function initSearch() {
        $('#mbp-user-search').on('input', function() {
            var q = $(this).val().toLowerCase();
            $('#mbp-users-table tbody tr').each(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(q) > -1);
            });
        });
    }

    /* ===== REFRESCAR LISTA ===== */
    function initRefresh() {
        $('#mbp-refresh-list').on('click', function(e) {
            e.preventDefault();
            location.reload();
        });
    }

})(jQuery);
