<?php
if (!defined('ABSPATH')) exit;
$s = MBP\AdminMenu::stats();
$cfg = MBP\AdminMenu::all_settings();
?>
<div class="wrap mbp-wrap">
    <h1>MySQL Backup Pro - Dashboard</h1>

    <div class="mbp-grid">
        <div class="mbp-card mbp-card-blue">
            <span class="dashicons dashicons-database"></span>
            <div><h2><?php echo (int)$s['total_backups']; ?></h2><p>Total Backups</p></div>
        </div>
        <div class="mbp-card mbp-card-green">
            <span class="dashicons dashicons-yes-alt"></span>
            <div><h2><?php echo (int)$s['successful']; ?></h2><p>Exitosos</p></div>
        </div>
        <div class="mbp-card mbp-card-red">
            <span class="dashicons dashicons-warning"></span>
            <div><h2><?php echo (int)$s['failed']; ?></h2><p>Fallidos</p></div>
        </div>
        <div class="mbp-card mbp-card-orange">
            <span class="dashicons dashicons-media-document"></span>
            <div><h2><?php echo esc_html($s['total_size']); ?></h2><p>Tamaño Total</p></div>
        </div>
    </div>

    <div class="mbp-section">
        <h2>Información de la Base de Datos</h2>
        <table class="widefat mbp-table">
            <tr><th width="200">Base de Datos</th><td><code><?php echo esc_html($s['db_name']); ?></code></td></tr>
            <tr><th>Tamaño</th><td><?php echo esc_html($s['db_size']); ?></td></tr>
            <tr><th>Tablas</th><td><?php echo (int)$s['table_count']; ?></td></tr>
            <tr><th>Próximo Backup</th><td><?php echo esc_html($s['next_backup']); ?></td></tr>
            <tr><th>Backups Automáticos</th>
                <td><?php echo $cfg['enabled']==='1'
                    ? '<span class="mbp-badge mbp-badge-green">Activado</span>'
                    : '<span class="mbp-badge mbp-badge-red">Desactivado</span>'; ?></td>
            </tr>
            <tr><th>Frecuencia</th><td><?php echo esc_html(ucfirst($cfg['frequency'])); ?></td></tr>
            <tr><th>Bucket S3</th>
                <td><?php echo MBP\S3Native::configured()
                    ? '<span class="mbp-badge mbp-badge-green">Configurado</span> ('.esc_html($cfg['s3_bucket']).')'
                    : '<span class="mbp-badge mbp-badge-gray">No configurado</span>'; ?></td>
            </tr>
        </table>
    </div>

    <div class="mbp-section">
        <h2>Último Backup</h2>
        <?php if ($s['last_backup']) : $lb = $s['last_backup']; ?>
        <table class="widefat mbp-table">
            <tr><th width="200">Archivo</th><td><code><?php echo esc_html($lb->file_name); ?></code></td></tr>
            <tr><th>Tamaño</th><td><?php echo MBP\AdminMenu::fmt_bytes((int)$lb->file_size); ?></td></tr>
            <tr><th>Estado</th><td><span class="mbp-badge mbp-badge-<?php echo $lb->status==='completed'?'green':'red'; ?>"><?php echo esc_html(ucfirst($lb->status)); ?></span></td></tr>
            <tr><th>Fecha</th><td><?php echo esc_html($lb->completed_at ?: $lb->created_at); ?></td></tr>
        </table>
        <?php else: ?>
            <p class="mbp-empty">Aún no hay backups. <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-backups'); ?>">Realizar el primero</a>.</p>
        <?php endif; ?>
    </div>

    <div class="mbp-section">
        <h2>Acciones Rápidas</h2>
        <p>
            <button id="mbp-run-backup" class="button button-primary button-lg">
                <span class="dashicons dashicons-cloud-upload"></span> Ejecutar Backup Ahora
            </button>
            <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-settings'); ?>" class="button button-secondary">
                <span class="dashicons dashicons-admin-generic"></span> Configuración
            </a>
            <a href="<?php echo admin_url('admin.php?page=mysql-backup-pro-backups'); ?>" class="button button-secondary">
                <span class="dashicons dashicons-list-view"></span> Ver Backups
            </a>
        </p>
    </div>
</div>
