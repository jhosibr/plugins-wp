<?php
if (!defined('ABSPATH')) exit;
$cfg = MBP\AdminMenu::all_settings();

$frequencies = [
    'hourly'      => 'Cada hora',
    'twicedaily'  => 'Dos veces al día',
    'daily'       => 'Diario',
    'weekly'      => 'Semanal',
    'monthly'     => 'Mensual',
];
?>
<div class="wrap mbp-wrap mbp-settings">
    <h1>Configuración</h1>

    <form id="mbp-settings-form">

        <!-- === GENERAL === -->
        <div class="mbp-section">
            <h2>Configuración General</h2>
            <table class="form-table">
                <tr>
                    <th>Backups Automáticos</th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" name="mbp_enabled" value="1" <?php checked($cfg['enabled'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description">Activa o desactiva los backups automáticos.</p>
                    </td>
                </tr>
                <tr>
                    <th>Frecuencia</th>
                    <td>
                        <select name="mbp_backup_frequency" class="regular-text">
                            <?php foreach ($frequencies as $v => $l) : ?>
                                <option value="<?php echo esc_attr($v); ?>" <?php selected($cfg['frequency'], $v); ?>><?php echo esc_html($l); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Con qué frecuencia se ejecutarán los backups automáticos.</p>
                    </td>
                </tr>
                <tr>
                    <th>Hora del Backup</th>
                    <td><input type="time" name="mbp_backup_time" value="<?php echo esc_attr($cfg['backup_time']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>Compresión Gzip</th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" name="mbp_compress_backup" value="1" <?php checked($cfg['compress'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description">Comprime los archivos SQL para reducir tamaño.</p>
                    </td>
                </tr>
                <tr>
                    <th>Retención (nº backups)</th>
                    <td>
                        <input type="number" name="mbp_retention_count" value="<?php echo esc_attr($cfg['retention']); ?>" min="1" max="100" class="small-text">
                        <p class="description">Número máximo de backups a conservar. Los más antiguos se eliminan automáticamente.</p>
                    </td>
                </tr>
                <tr>
                    <th>Email de Notificación</th>
                    <td>
                        <input type="email" name="mbp_notify_email" value="<?php echo esc_attr($cfg['notify_email']); ?>" class="regular-text">
                        <p class="description">Recibe notificaciones cuando un backup se complete o falle.</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- === S3 / CONTABO === -->
        <div class="mbp-section mbp-section-highlight">
            <h2><span class="dashicons dashicons-cloud"></span> Configuración S3 (Contabo / AWS / MinIO)</h2>

            <div class="mbp-notice mbp-notice-info">
                <strong>Para Contabo:</strong> Endpoint = <code>https://eu2.contabostorage.com</code> (ajusta la región).<br>
                <strong>Path Style</strong> debe estar <strong>activado</strong> para Contabo y MinIO.
            </div>

            <table class="form-table">
                <tr>
                    <th>Endpoint URL</th>
                    <td>
                        <input type="url" name="mbp_s3_endpoint" value="<?php echo esc_attr($cfg['s3_endpoint']); ?>" class="regular-text" placeholder="https://eu2.contabostorage.com">
                        <p class="description">URL del servicio S3. <strong>Contabo:</strong> <code>https://eu2.contabostorage.com</code> | <strong>AWS:</strong> déjalo vacío</p>
                    </td>
                </tr>
                <tr>
                    <th>Región</th>
                    <td>
                        <input type="text" name="mbp_s3_region" value="<?php echo esc_attr($cfg['s3_region']); ?>" class="regular-text" placeholder="default">
                        <p class="description">Región del bucket. Contabo usa <code>default</code>.</p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre del Bucket</th>
                    <td>
                        <input type="text" name="mbp_s3_bucket" value="<?php echo esc_attr($cfg['s3_bucket']); ?>" class="regular-text" placeholder="mi-bucket">
                    </td>
                </tr>
                <tr>
                    <th>Access Key</th>
                    <td>
                        <input type="password" name="mbp_s3_access_key" value="<?php echo esc_attr($cfg['s3_access_key']); ?>" class="regular-text" autocomplete="off">
                    </td>
                </tr>
                <tr>
                    <th>Secret Key</th>
                    <td>
                        <input type="password" name="mbp_s3_secret_key" value="<?php echo esc_attr($cfg['s3_secret_key']); ?>" class="regular-text" autocomplete="off">
                    </td>
                </tr>
                <tr>
                    <th>Path Style</th>
                    <td>
                        <label class="mbp-toggle">
                            <input type="checkbox" name="mbp_s3_path_style" value="1" <?php checked($cfg['s3_path_style'], '1'); ?>>
                            <span class="mbp-toggle-slider"></span>
                        </label>
                        <p class="description">Obligatorio para Contabo y MinIO. Desactívalo solo para AWS puro.</p>
                    </td>
                </tr>
            </table>

            <p>
                <button type="button" id="mbp-test-s3" class="button button-secondary">
                    <span class="dashicons dashicons-admin-site-alt3"></span> Probar Conexión S3
                </button>
                <span id="mbp-test-result" style="margin-left:12px;font-weight:600;"></span>
            </p>
        </div>

        <p class="submit">
            <button type="submit" class="button button-primary button-lg">
                <span class="dashicons dashicons-saved"></span> Guardar Configuración
            </button>
        </p>
    </form>
</div>
