<?php
if (!defined('ABSPATH')) exit;

// Cargar backups directamente
$backups = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}mbp_backups ORDER BY created_at DESC LIMIT 100", ARRAY_A);
?>
<div class="wrap mbp-wrap">
    <h1>Backups Realizados</h1>

    <p>
        <button id="mbp-run-backup" class="button button-primary">
            <span class="dashicons dashicons-cloud-upload"></span> Ejecutar Backup Ahora
        </button>
        <button id="mbp-refresh-list" class="button button-secondary">
            <span class="dashicons dashicons-update"></span> Actualizar
        </button>
    </p>

    <table class="widefat mbp-table" id="mbp-backups-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Archivo</th>
                <th>Tamaño</th>
                <th>Tablas</th>
                <th>Filas</th>
                <th>Tipo</th>
                <th>Estado</th>
                <th>S3</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($backups) : foreach ($backups as $b) :
                $tables = $b['tables_list'] ? count(explode(', ', $b['tables_list'])) : 0;
                $has_s3 = !empty($b['s3_key']);
            ?>
            <tr data-id="<?php echo (int)$b['id']; ?>">
                <td><?php echo (int)$b['id']; ?></td>
                <td><code><?php echo esc_html($b['file_name']); ?></code></td>
                <td><?php echo MBP\AdminMenu::fmt_bytes((int)$b['file_size']); ?></td>
                <td><?php echo $tables; ?></td>
                <td><?php echo number_format((int)$b['rows_count']); ?></td>
                <td><span class="mbp-type"><?php echo esc_html($b['backup_type']); ?></span></td>
                <td><span class="mbp-badge mbp-badge-<?php echo $b['status']==='completed'?'green':'red'; ?>"><?php echo esc_html($b['status']); ?></span></td>
                <td><?php echo $has_s3
                    ? '<span class="dashicons dashicons-yes-alt" style="color:#46b450"></span>'
                    : '<span class="dashicons dashicons-minus" style="color:#ccc"></span>'; ?></td>
                <td><?php echo esc_html($b['completed_at'] ?: $b['created_at']); ?></td>
                <td>
                    <button class="button mbp-btn-download" data-id="<?php echo (int)$b['id']; ?>" title="Descargar"><span class="dashicons dashicons-download"></span></button>
                    <button class="button mbp-btn-delete" data-id="<?php echo (int)$b['id']; ?>" title="Eliminar"><span class="dashicons dashicons-trash"></span></button>
                </td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="10" class="mbp-empty">No hay backups registrados.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Modal de progreso -->
    <div id="mbp-modal" style="display:none;">
        <div class="mbp-modal-bg"></div>
        <div class="mbp-modal-box">
            <h3>Ejecutando Backup...</h3>
            <div class="mbp-progress"><div class="mbp-progress-bar"></div></div>
            <p id="mbp-modal-msg">Por favor espere...</p>
        </div>
    </div>
</div>
