# MySQL Backup Pro - Guía de Instalación Paso a Paso

## Requisitos Previos

| Requisito | Versión mínima |
|-----------|---------------|
| WordPress | 5.8 |
| PHP | 7.4 (compatible con 8.4+) |
| MySQL/MariaDB | 5.7+ |
| Extensiones PHP | `mysqli`, `openssl`, `curl`, `zlib` (gzip) |

> **NO necesitas instalar Composer ni el AWS SDK.** Este plugin incluye un cliente S3 nativo que funciona con Contabo, AWS, MinIO, Wasabi, DigitalOcean Spaces y cualquier servicio compatible S3.

---

## Paso 1: Instalar el Plugin en WordPress

### Opción A - Subir ZIP (Recomendado)

1. Ve a tu panel de WordPress: **Plugins > Añadir nuevo > Subir plugin**
2. Haz clic en **Seleccionar archivo** y elige `mysql-backup-pro.zip`
3. Pulsa **Instalar ahora**
4. Tras la instalación, haz clic en **Activar plugin**

### Opción B - FTP / SFTP

1. Extrae el archivo `mysql-backup-pro.zip` en tu computadora
2. Sube la carpeta `mysql-backup-pro` a `/wp-content/plugins/`
3. Ve a WordPress: **Plugins** y pulsa **Activar** en "MySQL Backup Pro"

### Opción C - WP-CLI (para desarrolladores)

```bash
cd /ruta/a/wordpress/wp-content/plugins
unzip mysql-backup-pro.zip
wp plugin activate mysql-backup-pro
```

---

## Paso 2: Verificar Requisitos del Servidor

Después de activar, el plugin creará automáticamente:
- Una tabla en tu base de datos: `{prefijo}_mbp_backups`
- Una carpeta protegida: `wp-content/mysql-backup-pro/`

### Verificar extensiones PHP

En tu servidor, verifica que estas extensiones estén activas:

```bash
php -m | grep -iE 'mysqli|openssl|curl|zlib'
```

Deberías ver al menos estas 4 extensiones listadas. Si falta alguna, contacta a tu proveedor de hosting o habilítalas en `php.ini`:

```ini
extension=mysqli
extension=openssl
extension=curl
extension=zlib
```

> **Contabo:** En VPS de Contabo, las extensiones suelen venir activadas por defecto con PHP 8.x.

---

## Paso 3: Configurar el Bucket S3 (Contabo)

### 3.1 Obtener tus credenciales de Contabo

1. Inicia sesión en tu **Panel de Control de Contabo**
2. Ve a la sección **Object Storage** en el menú izquierdo
3. Haz clic en **Go to Object Storage Panel**
4. Navega a **Account > Security & Access**
5. Copia tu **Access Key** y tu **Secret Key**
6. Anota el nombre de tu **bucket** (ej: `backup-gestlife`)

### 3.2 Configurar en el plugin

1. En WordPress, ve a **MySQL Backup Pro > Configuración**
2. Sección **Configuración S3 (Contabo / AWS / MinIO)**:

| Campo | Valor para Contabo | Ejemplo |
|-------|-------------------|---------|
| **Endpoint URL** | `https://eu2.contabostorage.com` | Ajusta según tu región |
| **Región** | `default` | Siempre `default` para Contabo |
| **Nombre del Bucket** | Tu bucket | `backup-gestlife` |
| **Access Key** | Tu Access Key | (copia del panel) |
| **Secret Key** | Tu Secret Key | (copia del panel) |
| **Path Style** | ✅ Activado | Obligatorio para Contabo |

3. Haz clic en **Probar Conexión S3**
4. Si dice **"Conexión S3 exitosa"**, pulsa **Guardar Configuración**

### Endpoints de Contabo según región

| Región | Endpoint |
|--------|----------|
| EU (Alemania) | `https://eu2.contabostorage.com` |
| US Central | `https://usc1.contabostorage.com` |
| ASIA (Singapur) | `https://sin1.contabostorage.com` |

---

## Paso 4: Configurar Frecuencia de Backups

En la sección **Configuración General**:

| Campo | Recomendación |
|-------|--------------|
| Backups Automáticos | Activado ✅ |
| Frecuencia | `Diario` (o según necesidad) |
| Hora | `02:00` (madrugada, menos tráfico) |
| Compresión Gzip | Activado ✅ |
| Retención | `10` (conserva los últimos 10 backups) |
| Email de Notificación | Tu correo para recibir alertas |

Haz clic en **Guardar Configuración**.

---

## Paso 5: Realizar un Backup de Prueba

1. Ve a **MySQL Backup Pro > Backups**
2. Pulsa **Ejecutar Backup Ahora**
3. Espera a que termine (aparecerá una barra de progreso)
4. Al finalizar, verás el backup en la lista con:
   - Tamaño del archivo
   - Número de tablas y filas
   - Icono verde de S3 (si subió correctamente)

### Verificar en Contabo

1. Ve a tu panel de Object Storage de Contabo
2. Revisa la carpeta `mysql-backups/AAAA/MM/`
3. Deberías ver el archivo `.sql.gz` subido

### Verificar integridad con WP Users

1. Ve a **MySQL Backup Pro > WP Users (Test)**
2. Revisa que los usuarios mostrados coincidan con tu sitio
3. Descarga el archivo SQL del backup
4. Abre el archivo y busca `INSERT INTO wp_users` para confirmar que los datos están completos

---

## Paso 6: Configurar WP Cron (Importante para Hostings)

Para que los backups automáticos funcionen, WordPress necesita el sistema Cron.

### Opción A - WP Cron nativo (la mayoría de hostings)

Funciona automáticamente sin configuración adicional.

### Opción B - Cron del sistema operativo (más confiable)

Si tu hosting tiene problemas con WP Cron, configura un cron externo:

```bash
# Editar crontab
crontab -e

# Añadir esta línea para ejecutar cada hora:
0 * * * * wget -q -O - https://TU-DOMINIO.com/wp-cron.php?doing_wp_cron >/dev/null 2>&1
```

Y desactiva WP Cron en `wp-config.php`:

```php
define('DISABLE_WP_CRON', true);
```

---

## Solución de Problemas

### "No se pudo inicializar el cliente S3"

**Causa:** El endpoint está vacío o las credenciales son incorrectas.
**Solución:**
1. Verifica que el campo **Endpoint URL** tenga valor (ej: `https://eu2.contabostorage.com`)
2. Verifica Access Key y Secret Key
3. Asegúrate de que **Path Style** esté activado
4. Prueba la conexión de nuevo

### Los backups no se ejecutan automáticamente

**Causa:** WP Cron no está funcionando.
**Solución:**
1. Instala el plugin "WP Crontrol" para ver los cron jobs
2. Verifica que existe el evento `mbp_run_cron_backup`
3. Configura un cron externo (ver Paso 6)

### Error de memoria al hacer backup

**Solución:** Aumenta el límite en `wp-config.php`:

```php
define('WP_MEMORY_LIMIT', '512M');
ini_set('max_execution_time', '600');
```

### No llegan los correos de notificación

**Solución:**
1. Verifica que el campo **Email de Notificación** tiene un correo válido
2. Instala un plugin SMTP como "WP Mail SMTP" para enviar correos
3. Revisa la carpeta de spam

### Error "cURL error"

**Causa:** La extensión cURL de PHP no está activada.
**Solución:** Activa `extension=curl` en tu `php.ini` y reinicia el servidor web.

---

## Configuración para Otros Proveedores S3

### AWS S3
| Campo | Valor |
|-------|-------|
| Endpoint | `https://s3.us-east-1.amazonaws.com` (o tu región) |
| Región | `us-east-1` (o tu región) |
| Path Style | Desactivado |

### MinIO
| Campo | Valor |
|-------|-------|
| Endpoint | `https://tu-minio.com:9000` |
| Región | `us-east-1` |
| Path Style | Activado ✅ |

### Wasabi
| Campo | Valor |
|-------|-------|
| Endpoint | `https://s3.wasabisys.com` |
| Región | `us-east-1` |
| Path Style | Activado ✅ |

---

## Actualizar el Plugin

1. Desactiva el plugin actual
2. Borra la carpeta `mysql-backup-pro` de `/wp-content/plugins/`
3. Sube la nueva versión
4. Activa el plugin

> **Nota:** Tus configuraciones y backups previos se conservan en la base de datos.

---

## Soporte

- Email: El configurado en el plugin
- Repositorio: https://github.com/gestlifedev/plugin-wp-backups
